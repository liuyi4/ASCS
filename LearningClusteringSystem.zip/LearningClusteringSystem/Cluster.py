﻿class Cluster:

    def __init__(self,number_Gener_Attribute):


        #the ID of the Cluster: number of generalized attributes
        self.numGenerAttribute=number_Gener_Attribute

        #Whether should search rule in this sub searchspace
        #Default == True
        self.Active=True


        self.Close_folder=10

        #############################################
        ###### Information of a inner circle ########
        #############################################


        #Number of removed rules (Absumption)
        self.numAbsumptionRemoved=[]


        #Number of removed rules (Subsumption)
        self.numSumptionRemoved=[]


        #Number of evolved rules (Subsumption)
        self.numEvolved=[]


        #############################################
        ###### Information of a out circle ########
        #############################################

        #Number of removed rules (Absumption)
        self.Out_numAbsumptionRemoved=[]


        #Number of removed rules (Subsumption)
        self.Out_numSumptionRemoved=[]



        ####################################################
        ###### Information of the overall situation ########
        ####################################################

        #Number of removed rules (Absumption)
        self.totalNumAbsumptionRemoved=0


        #Number of removed rules (Subsumption)
        self.totalNumSumptionRemoved=0


        #Number of evolved rules (Subsumption)
        self.totalNumEvolved=0


        #the storage of the including rules in this cluster
        self.cluster=[]


        ####################################################
        ###### Information for control search       ########
        ####################################################
        self.Space_Possible_Rules=0

    def WhetherStop_Search(self):
        if self.totalNumAbsumptionRemoved+self.totalNumSumptionRemoved>self.Close_folder*self.Space_Possible_Rules:
            self.Active=False