﻿import random
 
 #A set of operations to deal with inner evolution
class Inner_Circle_Operations:

     def __init__(self, Representation_Operator, Rule_Operator):
         print ("Inner Circle Operations Loading Completed")

         self.Rep_Oper=Representation_Operator


         self.Rule_Oper=Rule_Operator

         #the minimal number of a rule to become a candidate of Absumption
         self.Absumption_Threshold=1

         #the minimal number of a rule to become a candidate of general search 
         #self.General_Search_Threshold=5


         # the rate of search in a gener level 
         self.General_Rate=0.5


         
    ##########################################################################################################################
    ####################                            The Covering Process && Match Process                          ###########
    ####################                                     Operators                                             ###########
    ##########################################################################################################################



     #To create & add covered rules into population, and return the ID of the created rule into match set
     def Add_rules_Covering(self,state,gener,population,Att_list,action,BigCircleId):

 
         #create a condition
         condition=self.Rep_Oper.createCondition_GeneralLevel(state,gener,Att_list)
         #print (condition)
         rule=self.Rule_Oper.Create_new_Single_Rule(condition, action,BigCircleId)
         #print (rule)
         #Add rule into population
         population.population[gener].cluster.append(rule)
         #update number of evolved rules
         population.population[gener].numEvolved[-1]+=1


         #Get the current Individual ID
         ID=[]
         ID.append(gener)
         ID.append(len(population.population[gener].cluster)-1)

         #update number of rules in this population
         population.numRules+=1


         return ID




     #state: state of instance
     #population: a population
     def Get_Match_List(self,state,population):
        # the match set
        Match_result=[] 
        for i in range(0,len(population.population)):
            for j in range(0,len(population.population[i].cluster)):
                if self.Rep_Oper.isConditionMatched(state,population.population[i].cluster[j][0]):
                    #Add the matched rule
                    temp=[]
                    temp.append(i)
                    temp.append(j)
                    Match_result.append(temp)

        return Match_result


     #Update the matchset
     #get the rule-list for undergoing absumption
     #get the rule-list for undergoing general search
     def UpDate_Training_Parameters_And_Absumption_And_Candidate(self, match_set, population, reward):
         self.UpDate_Training_Parameters(match_set,population, reward)
         Absumption_list, Candidate_List=self.Produce_Absumption_set_and_Search_set(match_set, population, reward)
         return Absumption_list, Candidate_List


     #Update the matchset
     def UpDate_Training_Parameters(self,match_set,population, reward):
         for ruleId in match_set:
             rule=population.population[ruleId[0]].cluster[ruleId[1]]
             if reward>1:
                 self.Rule_Oper.update_positive_prediction(rule,1)
             else:
                 self.Rule_Oper.update_negative_prediction(rule,1)



     #get the rule-list for undergoing absumption
     #get the rule-list for undergoing general search
     def Produce_Absumption_set_and_Search_set(self, match_set, population, reward):
         Absumption_list=[]
         Candidate_List=[]
         for ruleId in match_set:
             Reward_State=None
             if reward>1:
                 Reward_State=True
             else:
                 Reward_State=False

             if population.PN_State ^ Reward_State:  #not equal 
                  #print (self.PN_State , Reward_State, self.PN_State ^ Reward_State)                 
                  #Match and raise the absumption
                  Absumption_list.append(ruleId)
             else:
                  Candidate_List.append(ruleId)
         return Absumption_list, Candidate_List
             



                 

    ##########################################################################################################################
    ####################                                    Absumption                                             ###########
    ####################                                     Operators                                             ###########
    ##########################################################################################################################

     #the absumption process
     def Absumption(self,Absumption_list,state,population,BigCircle,space_Control):
         #if no rules need to be absumpted
         if not len(Absumption_list)>0:
             return None

         remove_d=self.Convert_Remove_List(Absumption_list)

         #Absumption 
         for Ab_ID in Absumption_list:
             # not all features are specified
             if Ab_ID[0]>0:
                 # the general level of absumption process
                 general_level=Ab_ID[0]-1
                 general_visit=self.Ab_Searchable(population,general_level)
                 if space_Control==False or (space_Control==True and general_visit==True):
                    #print(general_level)
                    #print(general_visit)
                    rule= population.population[Ab_ID[0]].cluster[Ab_ID[1]]
                    experience=self.Rule_Oper.Get_positive_prediction(rule)+self.Rule_Oper.Get_negative_prediction(rule)
                    numerosity=self.Rule_Oper.Get_numerosity(rule)
                    if experience>self.Absumption_Threshold:
                     
                        for i in range(0,numerosity):
                         
                            #update number of evolved rules
                            population.population[general_level].numEvolved[-1]+=1
                            #get the original condition for generate new condition
                            condition=self.Rule_Oper.Get_Condition(rule)
                            ab_condition=self.Rep_Oper.Absumption_Condition(state,condition,general_level)
                         
                            if not self.Ab_Is_condition_exist(population,general_level,ab_condition):
                                if not self.Inner_Subsume(BigCircle,population,ab_condition,general_level):
                                    self.Add_rule_Absumption(ab_condition,population,BigCircle,general_level)
                                else:
                                    population.population[general_level].numSumptionRemoved[-1]+=1
                                    population.population[general_level].totalNumSumptionRemoved+=1

         #remove absumpted rules
         self.Ab_remove_rules(remove_d,population)


     #Judge whether this rule exist Yes: True Not: False
     def Ab_Is_condition_exist(self,population, general_level, candidate):
        if candidate==None:
             return True

        for rule in population.population[general_level].cluster:
            condition=self.Rule_Oper.Get_Condition(rule)
            if self.Rep_Oper.Is_Same_Condition(condition,candidate):
                self.Rule_Oper.update_numerosity(rule,1)
                return True
        return False



     #Add new rule into the cluster
     def Add_rule_Absumption(self,condition,population,bigCircle,general_level):
         new_rule=self.Rule_Oper.Create_new_Single_Rule(condition,population.support_act,bigCircle)
         population.population[general_level].cluster.append(new_rule)

         #update number of rules in this population
         population.numRules+=1


     #Convert remove record from list to dictionary
     def Convert_Remove_List(self,Absumption_List):
         remove_d={}
         for ID in Absumption_List:
             if not ID[0] in remove_d.keys():
                 temp=[]
                 temp.append(ID[1])
                 remove_d.setdefault(ID[0],temp)
             else:
                 remove_d[ID[0]].append(ID[1])
                
         #print(remove_d)
         return remove_d

     #remove rules from absumption list
     def Ab_remove_rules(self,remove_d,population):
         for general_level in remove_d:
             count=0
             for id in remove_d[general_level]:
                 rule=population.population[general_level].cluster[id-count]
                 numerosity=self.Rule_Oper.Get_numerosity(rule)
                 population.population[general_level].numAbsumptionRemoved[-1]+=numerosity
                 population.population[general_level].totalNumAbsumptionRemoved+=numerosity
                 #remove according to id 
                 population.population[general_level].cluster.pop(id-count)
                 count+=1
                 #update number of rules in this population
                 population.numRules-=1

    #Check whether the general ID is searchable
     def Ab_Searchable(self,population,general_level):
        result=population.population[general_level].Active
        return result



    ##########################################################################################################################
    ####################                            Rule Discovery                                                 ###########
    ####################                              General-search                                               ###########
    ##########################################################################################################################

     #Convert candidate from list to dictionaty
     def GeneralRule_Convert_General_Search_List(self,candidate_list,population):
        candidate={}
        numerosity_value={}
        for ID in candidate_list:
            rule=population.population[ID[0]].cluster[ID[1]]
            # read numerosity of the rule
            numerosity= self.Rule_Oper.Get_numerosity(rule)

            if not ID[0] in candidate.keys():
                    temp=[]
                    temp.append(ID[1])
                    candidate.setdefault(ID[0],temp)
                    numerosity_value.setdefault(ID[0],numerosity)


            else:
                    candidate[ID[0]].append(ID[1])
                    numerosity_value[ID[0]]+=numerosity

        #Remove the insufficient candidate
        for Cluster_ID in candidate:
            threshold=numerosity_value[Cluster_ID]/len(candidate[Cluster_ID])
            remove_list=[]
            for rule_ID in candidate[Cluster_ID]:
                # get the rule
                rule=population.population[Cluster_ID ].cluster[rule_ID]
                numerosity=self.Rule_Oper.Get_numerosity(rule)
                if numerosity+1<threshold:
                    remove_list.append(rule_ID)

            #remove the bad candidate
            for rule_ID in remove_list:
                candidate[Cluster_ID].remove(rule_ID)

        return candidate



     #Produce a new rule for general search
     def GeneralRule_Produce_Single_Rule(self,condition, population, general_level,bigCircle,state):

         #Whether keep the original general or attempt to search in a more general search-space
         if random.random()<self.General_Rate:
             general_Level=general_level
         else:
             if general_level<len(condition):
                general_Level=general_level+1
             else:
                 general_Level=general_level

         population.population[general_Level].WhetherStop_Search()
         if population.population[general_Level].Active==False:
             return
         #print(general_Level)
         #update number of evolved rules
         population.population[general_Level].numEvolved[-1]+=1

         new_condition=self.Rep_Oper.Gener_Condition(condition,general_Level,state)
         # If new rule does not exist introduce the new rule
         if not self.GeneralRule_Is_condition_exist(population, general_Level, new_condition):
             if not self.Inner_Subsume(bigCircle,population,new_condition,general_Level):
                self.GeneralRule_Add_rule(new_condition, population,bigCircle,general_Level)
             else:
                 population.population[general_level].numSumptionRemoved[-1]+=1
                 population.population[general_level].totalNumSumptionRemoved+=1



     #Judge whether this rule exist Yes: True Not: False
     def GeneralRule_Is_condition_exist(self,population, general_level, candidate):
        for rule in population.population[general_level].cluster:
            condition=self.Rule_Oper.Get_Condition(rule)
            if self.Rep_Oper.Is_Same_Condition(condition,candidate):
                self.Rule_Oper.update_numerosity(rule,1)
                return True
        return False


     #Add new rule into the cluster
     def GeneralRule_Add_rule(self,condition,population,bigCircle,general_level):
         new_rule=self.Rule_Oper.Create_new_Single_Rule(condition,population.support_act,bigCircle)
         population.population[general_level].cluster.append(new_rule)
         #update number of rules in this population
         population.numRules+=1



     #Implement the general search
     def General_Search(self,state,candidate_list, population ,bigCircle):
         candidate_dictionary= self.GeneralRule_Convert_General_Search_List(candidate_list, population)

         #If the ruleset is saturated return
         if population.numRules>population.Maximum_SearchNumber:
             return

         #not sufficient candidate for search
         if not len(candidate_dictionary)>0:
             return 

         for general_Id in candidate_dictionary:
             rule_Id=random.sample(candidate_dictionary[general_Id],1)
             rule=population.population[general_Id].cluster[rule_Id[0]]
             condition=self.Rule_Oper.Get_Condition(rule)
             self.GeneralRule_Produce_Single_Rule(condition, population, general_Id,bigCircle,state)



    ##########################################################################################################################
    ####################                            Subsumption Inner Circle                                       ###########
    ####################                              operators                                                    ###########
    ##########################################################################################################################

     def Inner_Subsume(self, inner_circle, population, candidate, candidate_general):
         # if in the first inner cicle does not active the subsume process
         if inner_circle<1:
            return False

         #can be subsumed
         for ID in range(candidate_general+1,len(population.population)):
             if self.Is_Rule_Subsumable(population.population[ID],candidate,inner_circle):
                 return True

         #cannot be subsumed
         return  False


     #Judge whether this rule could be subsumed 
     def Is_Rule_Subsumable(self,cluster,candidate,candidate_Circle_ID):
        for rule in cluster.cluster:
            Circle_ID=self.Rule_Oper.Get_Circle_Id(rule)
            if Circle_ID<candidate_Circle_ID:
                condition=self.Rule_Oper.Get_Condition(rule)
                if self.Rep_Oper.Is_Condition_Subsumeable(condition,candidate):
                    return True
        return False