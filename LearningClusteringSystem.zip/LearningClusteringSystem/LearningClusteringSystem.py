﻿from Population import population
from environment import environment
from environment import Prime_environment
from environment import Real_environment

from Inner_Circle import Inner_Circle_Operations
from Out_Circle import Out_Circle_Operations

from Representation_format import Ternary_Alphabet
from Representation_format import Interger_Alphabet

from Rule import Rule001
import random
import time
import os
from TimeCalculater import Time_Calculate
from Calculate_RatePattern import Compare_solution
from ReadPopulation import ReadPopulation_ContinueTrain
from Visualization import Value_Knowledge_Running

class Learning_Clustering_System:
    def __init__(self,problem_ID,c_address,r_address):

        #############################
        ## Record the initial time ##
        #############################
        self.format_time_2=None
        self.Hour_2=None
        self.Min_2=None
        self.second_2=None
        self.day_2=None


        #The initial value of bigcircle
        self.Big_Circle=0

        #define the running manchine
        self.Is_LinuX=False


        #whether active the pattern record
        self.Pattern_Traing_Record=True
        if self.Pattern_Traing_Record==True:
            save_address="Pattern_Train\\"
            self.VKR=Value_Knowledge_Running(save_address)



        #whether active strategy for boolean domain
        self.Whether_Boolean=False
        #Boolean Problem
        if problem_ID==0:
            ##### For the interacted environment
            self.env=environment(1000)
        
            #only for hidden problem
            self.env.Hidden_bits=5


            #['MUX','Carry','Parity','Majority','Hidden MUX','Hidden Carry','Hidden Majority On','Hierarchically composed problem']
            self.problem_id=1
            self.feature_length=6
            self.action_list=[0,1]
            self.attribute_list=self.env.Generate_attribute_List(self.feature_length)
            #Whether the problem is boolean
            self.Whether_Boolean=True

            # the type of the rule
            self.Rule_Type=Rule001()


            # the type of the representation
            self.Represent_type=Ternary_Alphabet()


        #for prime problem
        elif problem_ID==1:
            
            self.feature_length=5
            self.env=Prime_environment(self.feature_length,1000)


            self.problem_id=0
            self.action_list=[0,1]
            self.attribute_list=self.env.Generate_attribute_List(self.feature_length)
            self.Whether_Boolean=True

            # the type of the rule
            self.Rule_Type=Rule001()


            # the type of the representation
            self.Represent_type=Ternary_Alphabet()


        #For interger problem
        elif problem_ID==2:
            #[0:ZOO, 1:Balance, 2:breast Cancer]
            self.problem_id=1
            self.env=Real_environment(1000,self.problem_id)
            self.feature_length=self.env.length
            self.action_list=self.env.action_list
            self.attribute_list=self.env.Generate_attribute_List(self.feature_length)
            self.Whether_Boolean=False

            print("Interger")
            # the type of the rule
            self.Rule_Type=Rule001()

            # the type of the representation
            self.Represent_type=Interger_Alphabet(self.env.action_value_candidate)


        #Set the searchable spaces
        self.Space_Control=True
        self.min=0
        self.max=self.feature_length
        #self.max=63

        #runing iterations
        self.entire_iterations=1201


        #subsumption (explorer) trigger iterations
        self.trigger_iteration=100

        #the sample size for checking the accuracy
        self.test_iterations=200

        #Control the search-spaces
        #self.Piece_Circle=3

        # Size
        self.Search_Size=500



        self.Populations={}
        self.Initial_Populations()

        
        #the inner circle operator
        self.Inner_Circle_Operator=Inner_Circle_Operations(self.Represent_type, self.Rule_Type)

        #the out circle operators
        self.Out_Circle_Operator=Out_Circle_Operations(self.Represent_type, self.Rule_Type)

        #store the accuracy of the training before big circle
        self.Accuracy=[]

        #store the accuracy of the training after big circle
        self.After_Accuracy=[]

        #store the number of rules in the training process
        self.num_Rules=[]


        #store the number of rules before compaction
        self.Before_num_Rules=[]

        #A model for calculate time
        self.TC=Time_Calculate()
        #record the time for running 
        self.Running_Time=0


        #record the time for first achieving 100% accuracy
        self.Max_Accuracy_achieve=False
        self.Max_Accurate_Time=0

        #record the time for first achieving 100% pattern
        self.Max_Pattern_achieve=False
        self.Max_Pattern_Time=0

        ##################################
        #  Activate the pattern record  ##
        ##################################
        self.Pattern_Record=False
        if self.Pattern_Record==True:
            self.Com_sol=Compare_solution(c_address,self.Is_LinuX)


        #record the percentage of patterns
        self.Pattern_Rate=[]

        ###  Check Whether Retain #########
        if r_address!=None:
            self.Initial_Previous_Population(r_address)




        ##############################
        ########## Run the ASCS ######
        ##############################
        self.Run()




    #initialize the populations
    def Initial_Populations(self):
        for action in self.action_list:
            self.Initial_Population_Single_Class(action)



    #Create two populations for a single class 
    #Population: PNState=Fale: complete incorrect map
    #population: PNState=True: complete correct map
    def Initial_Population_Single_Class(self,action):
        population_correct=population(True,self.feature_length,action, self.Search_Size,self.env.Generate_attribute_PossibleValueLength_List_Boolean(self.feature_length),len(self.action_list),self.max,self.min)
        population_incorrect=population(False,self.feature_length,action, self.Search_Size,self.env.Generate_attribute_PossibleValueLength_List_Boolean(self.feature_length),len(self.action_list),self.max,self.min)
        temp=[]
        temp.append(population_correct)
        temp.append(population_incorrect)
        self.Populations.setdefault(action,temp)


    def Print_population(self):
        for ActionId in self.Populations:
            positive_population=self.Populations[ActionId][0]
            negative_population=self.Populations[ActionId][1]
            print("*********************************************",negative_population.numRules )
            for cluster in negative_population.population:
                print (cluster.numGenerAttribute," : ",cluster.numEvolved[-1],cluster.numAbsumptionRemoved[-1],cluster.numSumptionRemoved[-1])
                print("=========================================")
                if len(cluster.cluster)>0:
                    for rule in cluster.cluster:
                        print( rule)

            print("*********************************************",positive_population.numRules )
            for cluster in positive_population.population:
                print (cluster.numGenerAttribute," : ",cluster.numEvolved[-1],cluster.numAbsumptionRemoved[-1],cluster.numSumptionRemoved[-1])
                print("=========================================")
                if len(cluster.cluster)>0:
                    for rule in cluster.cluster:
                        print( rule)

        print("Accuracy",self.Accuracy)

    def Inner_Circle_Covering(self,state, BigCircle):
        for ActionId in self.Populations:
            #positive population
            positive_population=self.Populations[ActionId][0]
            #negative population
            negative_population=self.Populations[ActionId][1]

            #get rules that covered the input instance
            P_M=self.Inner_Circle_Operator.Get_Match_List(state,positive_population)
            N_M=self.Inner_Circle_Operator.Get_Match_List(state,negative_population)
           
            #None rule can cover instance active the cover process
            if len(P_M)+len(N_M)==0:
                #Calculate the general level 
                #two strategies:
                #First: employ the priority of general
                #Second: employ the priority of number of rules

                general_level_P=positive_population.Produce_Search_General(0)
                general_level_N=negative_population.Produce_Search_General(0)



                P_M.append(self.Inner_Circle_Operator.Add_rules_Covering(state,general_level_P,positive_population,self.attribute_list,positive_population.support_act,BigCircle))
                N_M.append(self.Inner_Circle_Operator.Add_rules_Covering(state,general_level_N,negative_population,self.attribute_list,negative_population.support_act,BigCircle))

            reward=self.env.executeAction(self.problem_id,state,ActionId)
            P_Absumption_list,P_candidate_list =self.Inner_Circle_Operator.UpDate_Training_Parameters_And_Absumption_And_Candidate(P_M,positive_population,reward)
            N_Absumption_list,N_candidate_list =self.Inner_Circle_Operator.UpDate_Training_Parameters_And_Absumption_And_Candidate(N_M,negative_population,reward)

            self.Inner_Circle_Operator.General_Search(state,P_candidate_list, positive_population ,BigCircle)
            self.Inner_Circle_Operator.General_Search(state,N_candidate_list, negative_population ,BigCircle)



            self.Inner_Circle_Operator.Absumption(P_Absumption_list,state,positive_population,BigCircle,self.Space_Control)
            self.Inner_Circle_Operator.Absumption(N_Absumption_list,state,negative_population,BigCircle,self.Space_Control)

    def Prediction_Accuracy(self):
        #the number of correct predicted instances
        correct=0.0
        #the number of uncovered instance
        unmatch=0.0
        #the number of incorrect predicted instances
        incorrect=0.0

        for i in range(0,self.test_iterations):
            count=0
            prediction_list=self.Out_Circle_Operator.Initial_prediction_list(self.env.action)

            state=self.env.Create_Set_condition(self.feature_length)
            for ActionId in self.Populations:
                positive_population=self.Populations[ActionId][0]
                negative_population=self.Populations[ActionId][1]

                
                reward=self.env.executeAction(self.problem_id,state,ActionId)

                count+=self.Out_Circle_Operator.TrainingTest_Update_Parameters_and_predictionlist(state,positive_population,reward,prediction_list)
                count+=self.Out_Circle_Operator.TrainingTest_Update_Parameters_and_predictionlist(state,negative_population,reward,prediction_list)

                
            if count==0:
                prediction_list=None

            p_action=self.Out_Circle_Operator.output_action(prediction_list)
            #print(prediction_list)
            #print(p_action)
            if p_action!=None:
                reward=self.env.executeAction(self.problem_id,state,p_action)
                if reward>1:
                    correct+=1
                else:
                    incorrect+=1
            else:
                unmatch+=1

        Prediction_result=round(100.0*correct/self.test_iterations,1)

        for ActionId in self.Populations:
            print("A:",str(ActionId),"positive",self.Populations[0][0].numRules)
            print("A:",str(ActionId) ,"negative",self.Populations[0][1].numRules)

        print("Accuracy",Prediction_result)
        print("Unmatch rate:",unmatch/self.test_iterations )
        print("incorrect rate:",incorrect/self.test_iterations )

        return Prediction_result

    def OutCircle(self,iteration):
        #Accuracy before big circle
        Prediction_result=self.Prediction_Accuracy()
        #record
        self.Accuracy.append(Prediction_result)
        rule_num=self.Calculate_number_Rules()
        self.Before_num_Rules.append(rule_num)



        for ActionId in self.Populations:
            positive_population=self.Populations[ActionId][0]
            negative_population=self.Populations[ActionId][1]

            self.Out_Circle_Operator.TrainingTest_Implement_Remove(positive_population)
            self.Out_Circle_Operator.TrainingTest_Implement_Remove(negative_population)


            self.Out_Circle_Operator.ER_Implement(positive_population,negative_population)
            self.Out_Circle_Operator.ER_Implement(negative_population, positive_population)

            self.Out_Circle_Operator.Out_Implement_Subsumption(positive_population)
            self.Out_Circle_Operator.Out_Implement_Subsumption(negative_population)


            self.Out_Circle_Operator.Set_Properties(positive_population, self.Big_Circle)
            self.Out_Circle_Operator.Set_Properties(negative_population, self.Big_Circle)

        #Accuracy after big circle
        if self.Whether_Boolean==True:
            self.Out_Circle_Operator.CrossOver_Population(self.Populations[0][0],self.Populations[1][1],self.feature_length,self.Big_Circle)
            self.Out_Circle_Operator.CrossOver_Population(self.Populations[1][0],self.Populations[0][1],self.feature_length,self.Big_Circle)

        Prediction_result=self.Prediction_Accuracy()
        self.After_Accuracy.append(Prediction_result)

        if Prediction_result==1.0 and self.Max_Accuracy_achieve==False:
            format_time_1,Hour_1,Min_1,second_1,day_1=self.TC.startTimer()
            self.Max_Accurate_Time=self.TC.elapsed(Hour_1,self.Hour_2,Min_1,self.Min_2,second_1,self.second_2,day_1,self.day_2)
            self.Max_Accuracy_achieve=True

        if self.Pattern_Record:
            for Action in self.Populations:
                positive_population=self.Populations[Action][0]
                for cluster in positive_population.population:
                    for rule in cluster.cluster:
                        self.Com_sol.compare_rule(rule[0],rule[1])
                negative_population=self.Populations[Action][1]

                for cluster in negative_population.population:
                    for rule in cluster.cluster:
                        self.Com_sol.compare_rule(rule[0],rule[1])

            P_Rate=self.Com_sol.Calculate_Rate()
            self.Pattern_Rate.append(P_Rate)
            self.Com_sol.ReSet()

            if P_Rate==1.0 and self.Max_Pattern_achieve==False:
                format_time_1,Hour_1,Min_1,second_1,day_1=self.TC.startTimer()
                self.Max_Pattern_Time=self.TC.elapsed(Hour_1,self.Hour_2,Min_1,self.Min_2,second_1,self.second_2,day_1,self.day_2)
                self.Max_Pattern_achieve=True

        rule_num=self.Calculate_number_Rules()
        self.num_Rules.append(rule_num)
        self.Big_Circle+=1 

        if self.Pattern_Traing_Record==True:
            
            Map,number=self.VKR.Generate_Knowledge(self.Populations[0][0],self.Populations[1][0],self.feature_length)
            self.VKR.Drew_NOACT(Map,number,Prediction_result,iteration)

            
    #############################################################
    ############         Store Result                   ######### 
    ############        rule-set & Train-Performance    #########
    #############################################################              


    def Convert_Population_To_String_Boolean(self):
        result=""
        count=0
        for Action in self.Populations:
            positive_population=self.Populations[Action][0]

            for cluster in positive_population.population:
                for rule in cluster.cluster:
                    count+=1
                    result+=self.Rule_Type.Covert_Rule_String(rule)
        count_result=str(count)+"\n"
        result+=count_result
        return result

    def Convert_Population_To_String_Real(self):
        result=""
        count=0
        for Action in self.Populations:
            positive_population=self.Populations[Action][0]

            for cluster in positive_population.population:
                for rule in cluster.cluster:
                    count+=1
                    result+=self.Rule_Type.Covert_Rule_String(rule)

            negative_population=self.Populations[Action][1]

            for cluster in negative_population.population:
                for rule in cluster.cluster:
                    count+=1
                    result+=self.Rule_Type.Covert_Rule_String(rule)

        count_result=str(count)+"\n"
        result+=count_result
        return result

    def save_performance(self,txt,name):
        f=open(name,'wb')
        f.write(txt.encode())
        f.close()


    #work name: the name of context e.g.population or training performance
    #problem name: name of the testwed problem
    def Generate_Store_Name(self,work_name,problem_name):
        F,H,M,S,Ye,Mo,Da=self.GetTimer()
        file_type='.txt'
        if self.Is_LinuX==False:
            name='Result/'+str(self.feature_length)+'_'+problem_name+'_'+work_name+'_'+str(Ye)+'_'+str(Mo)+'_'+str(Da)+'_'+str(H
            )+'_'+str(M)+'_'+str(S)+file_type
        else:
            name=os.getcwd()+'/LCUS/Result/'+str(self.feature_length)+'_'+problem_name+'_'+work_name+'_'+str(Ye)+'_'+str(Mo)+'_'+str(Da)+'_'+str(H
            )+'_'+str(M)+'_'+str(S)+file_type
        return name


    def GetTimer(self):
        local_time= time.localtime(time.time())
        format_time=time.strftime('DAY: %Y-%m-%d  Time: %H : %M : %S',local_time)

        Year= local_time[0]
        Month=local_time[1]
        day=local_time[2]
        Hour= local_time[3]
        Min= local_time[4]
        second= local_time[5]
        return format_time,Hour,Min,second,Year,Month,day


    def Covert_List_ToString(self,Input_list):
        result=""
        for infor in Input_list:
            result+=str(infor)+' '
        result+="\n"
        return result

    #save the training performance
    def Convert_TrainingPerformance_ToString(self):
        result=""
        result+="BeforeAccuracy::"+self.Covert_List_ToString(self.Accuracy)+"\n"
        result+="AfterAccuracy::"+self.Covert_List_ToString(self.After_Accuracy)+"\n"
        result+="BeforenumRules::"+self.Covert_List_ToString(self.Before_num_Rules)+"\n"
        result+="AfternumRules::"+self.Covert_List_ToString(self.num_Rules)+"\n"
        result+="PatternRate::"+self.Covert_List_ToString(self.Pattern_Rate)+"\n"
        result+="Time_Completed::"+str(self.Running_Time)+"\n"+"\n"
        result+="Time_Accuracy::"+str(self.Max_Accurate_Time)+"\n"+"\n"
        result+="Time_Pattern::"+str(self.Max_Pattern_Time)+"\n"+"\n"
        return result



    def Save_Result(self):
        if self.Whether_Boolean:
            result=self.Convert_Population_To_String_Boolean()
        else:
            result=self.Convert_Population_To_String_Real()
        #save the population
        save_name=self.Generate_Store_Name("Population", self.env.problems_involved[self.problem_id])
        self.save_performance(result,save_name)

        #save performance
        result=self.Convert_TrainingPerformance_ToString()
        save_name=self.Generate_Store_Name("Performance", self.env.problems_involved[self.problem_id])
        self.save_performance(result,save_name)


    #Calculate the total number of rules in the evaluation pool
    def Calculate_number_Rules(self):
        count=0
        for Action in self.Populations:
            positive_population=self.Populations[Action][0]

            for cluster in positive_population.population:
                count+=len(cluster.cluster)
        return count






    #############################################################
    ############    Continue Training                   ######### 
    #############################################################  

    def Initial_Previous_Population(self,address):
        RPC=ReadPopulation_ContinueTrain(address,self.Is_LinuX)
        for rule in RPC.population:
            gener=self.count_general(rule[0])
            if rule[3]>0:
                self.Populations[rule[1]][0].population[gener].cluster.append(rule)                
            if rule[4]>0:
                self.Populations[rule[1]][1].population[gener].cluster.append(rule) 


    def count_general(self,condition):
        count=0
        for cod in condition:
            if cod=='#':
                count+=1
        return count


    #############################################################
    ############         RUN     LCUS                   ######### 
    #############################################################  

    def Run(self):
        self.format_time_2,self.Hour_2,self.Min_2,self.second_2,self.day_2=self.TC.startTimer()
        for i in range(1,self.entire_iterations):
            
            if i % self.trigger_iteration==0:
               #self.Print_population()
               self.OutCircle(i)
               print("CircleID",self.Big_Circle)
            else:
                state=self.env.Create_Set_condition(self.feature_length)
                self.Inner_Circle_Covering(state,self.Big_Circle)

        format_time_1,Hour_1,Min_1,second_1,day_1=self.TC.startTimer()
        self.Running_Time=self.TC.elapsed(Hour_1,self.Hour_2,Min_1,self.Min_2,second_1,self.second_2,day_1,self.day_2)
        self.Print_population()
        self.Save_Result()

        

#0: Boolean Problem 1: Prime Problem 2: Real Problem
address="MUX11RCR2019_7_11_5_58_34.txt"
#R_address=None
R_address='11_MUX_Population_2019_12_11_21_34_37.txt'
LCS=Learning_Clustering_System(0,address,None) 