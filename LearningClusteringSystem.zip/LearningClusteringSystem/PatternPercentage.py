﻿import os
from ReadPopulation import ReadPopulation_Visualization

class ProducePatternPercentage:

    def __init__(self, XCS, UCS, target):
        self.XCS_Address=XCS
        self.UCS_Address=UCS
        
        self.UCS=[]
        self.XCS=[]
        self.ASCS=[]
        #rv=ReadPopulation_Visualization(target)

        #self.target=rv.population

        self.target=self.read_target_map(target)
        self.Read_Populations()

        self.Calculate_Rate()

    def GetFileList(self,path,type):
        FileList=[]
        FindPath=path
        if self.Is_File_Exist(FindPath):
            FileNames=os.listdir(FindPath)
            for i in FileNames:
                if type in i:
                    FileList.append(path+'\\'+i)
        return FileList

    def Read_Information(self,path):
        read_information=open(path,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        return information


    def Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)

    def create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        return rule


    def Read_Populations(self):
        file_list_UCS=self.GetFileList(self.UCS_Address,'.txt')
        for file in file_list_UCS:
            population=[]
            information=self.Read_Information(file)
            for raw in information:
                infs=raw.split(' ->')
                condition=infs[0].split(" ")
                for i in range(0,len(condition)):
                    if condition[i]!='#':
                        condition[i]=int(condition[i])
                action= int(infs[1].split(' ')[0])
                rule=self.create_rule(condition,action)
                population.append(rule)
            self.UCS.append(population)

        file_list_XCS=self.GetFileList(self.XCS_Address,'.txt')
        for file in file_list_XCS:
            population=[]
            information=self.Read_Information(file)
            for raw in information:
                infs=raw.split(' -')[0].split(' : ')
                condition=[]
                for str in infs[0]:
                    if str!=" ":
                        if str!='#':
                            condition.append(int(str))
                        else:
                            condition.append(str)
                action=int(infs[1])
                rule=self.create_rule(condition,action)
                population.append(rule)
            self.XCS.append(population)
                #print(infs)


    def Is_Same_Condition(self,condition_1,condition_2):
        for i in range(0,len(condition_1)):
            if condition_1[i] != condition_2[i]:
                return False
        return True


    def Calculate_Rate(self):
        UCS_result=[]
        UCS_total=0
        UCS_num=0
        for pop in self.UCS:
            count=0
            for T_rule in self.target:
                for U_rule in pop:
                    if T_rule[1]==U_rule[1] and T_rule[0]==U_rule[0]:
                        count+=1
                        break
            result=1.0*count/len(self.target)
            UCS_total+=result
            UCS_num+=len(pop)
            UCS_result.append(result)

        XCS_result=[]
        XCS_total=0
        XCS_num=0
        for pop in self.XCS:
            count=0
            for T_rule in self.target:
                for X_rule in pop:
                    if T_rule[1]==X_rule[1] and T_rule[0]==X_rule[0]:
                        count+=1
                        break
            result=1.0*count/len(self.target)
            XCS_total+=result
            XCS_num+=len(pop)
            XCS_result.append(result)


        print('XCS',XCS_total/len(XCS_result),XCS_num/len(self.XCS))
        print('UCS',UCS_total/len(UCS_result),UCS_num/len(self.UCS))


    def read_target_map(self, address):
        population=[]
        information=self.Read_Information(address)
        for raw in information:
            infs= raw.split('\n')[0].split('  : ')
            condition=infs[0].split(" ")
            for i in range(0,len(condition)):
                if condition[i]!='#':
                    condition[i]=int(condition[i])
            action=int(infs[1])
            rule=self.create_rule(condition,action)
            population.append(rule)
        return population

    def Read_ASCS(self,address):
        file_list=self.GetFileList(address,'.txt')
        for file in file_list:
            rv=ReadPopulation_Visualization(file)
            self.ASCS.append(rv.population)
        ASCS_result=[]
        ASCS_total=0
        ASCS_num=0
        for pop in self.ASCS:
            count=0
            for T_rule in self.target:
                for X_rule in pop:
                    if T_rule[1]==X_rule[1] and T_rule[0]==X_rule[0]:
                        count+=1
                        break
            result=1.0*count/len(self.target)
            ASCS_total+=result
            ASCS_num+=len(pop)
            ASCS_result.append(result)


        print('ASCS',ASCS_total/len(ASCS_result),ASCS_num/len(self.ASCS))


#T='P_Rate\\target\\8_Majority_Population_2020_1_10_18_55_44.txt'
#UCS='P_Rate\\UCS\\8MAJ'
#XCS='P_Rate\\XCS\\8MAJ'

#T='P_Rate\\target\\10_Carry_Population_2020_1_11_2_13_30.txt'
#UCS='P_Rate\\UCS\\10CAR'
#XCS='P_Rate\\XCS\\10CAR'

#T='P_Rate\\target\\14_Carry_Population_2020_1_11_12_57_51.txt'
#UCS='P_Rate\\UCS\\14CAR'
#XCS='P_Rate\\XCS\\14CAR'

#T='P_Rate\\target\\MUX11RCR2019_7_11_5_58_34.txt'
#UCS='P_Rate\\UCS\\11MUX'
#XCS='P_Rate\\XCS\\11MUX'
#ASCS='P_Rate\\ASCS\\11MUX'


#T='P_Rate\\target\\MUX20RCR2019_7_12_15_2_49.txt'
#UCS='P_Rate\\UCS\\20MUX'
#XCS='P_Rate\\XCS\\20MUX'
#ASCS='P_Rate\\ASCS\\20MUX'

#T='P_Rate\\target\\MUX6RCR2019_7_10_17_27_20.txt'
#UCS='P_Rate\\UCS\\6MUX'
#XCS='P_Rate\\XCS\\6MUX'
#ASCS='P_Rate\\ASCS\\6MUX'



#T='P_Rate\\target\\MUX6RCR2019_7_10_17_27_20.txt'
#UCS='P_Rate\\UCS\\6MUX'
#XCS='P_Rate\\XCS\\6MUX'
#ASCS='P_Rate\\ASCS\\6MUX'


#T='P_Rate\\target\\12_Carry_Population_2020_1_13_18_11_1.txt'
#UCS='P_Rate\\UCS\\12CAR'
#XCS='P_Rate\\XCS\\12CAR'


#T='P_Rate\\target\\Majority11RCR32019_8_1_21_28_10.txt'
#UCS='P_Rate\\UCS\\11MAJ'
#XCS='P_Rate\\XCS\\11MAJ'


#T='P_Rate\\target\\12_Majority_Population_2019_12_14_8_36_52.txt'
#UCS='P_Rate\\UCS\\12MAJ'
#XCS='P_Rate\\XCS\\12MAJ'



#T='P_Rate\\target\\13_Majority_Population_2019_12_30_5_50_5.txt'
#UCS='P_Rate\\UCS\\13MAJ'
#XCS='P_Rate\\XCS\\13MAJ'

#T='P_Rate\\target\\MUX37RCR2019_7_13_6_32_10.txt'
#UCS='P_Rate\\UCS\\37MUX'
#XCS='P_Rate\\XCS\\37MUX'
#ASCS='P_Rate\\ASCS\\37MUX'


#T='P_Rate\\target\\6_Carry_Population_2020_1_23_1_20_29.txt'
#UCS='P_Rate\\UCS\\6CAR'
#XCS='P_Rate\\XCS\\6CAR'


#T='P_Rate\\target\\8_Carry_Population_2020_1_18_8_21_14.txt'
#UCS='P_Rate\\UCS\\8CAR'
#XCS='P_Rate\\XCS\\8CAR'

#T='P_Rate\\target\\14_Majority_Population_2020_1_15_2_38_49.txt'
#UCS='P_Rate\\UCS\\14MAJ'
#XCS='P_Rate\\XCS\\14MAJ'


T='P_Rate\\target\\MUX70RCR2019_7_22_19_32_7.txt'
UCS='P_Rate\\UCS\\70MUX'
XCS='P_Rate\\XCS\\70MUX'
#ASCS='P_Rate\\ASCS\\70MUX'

PPP=ProducePatternPercentage(XCS,UCS,T)
#PPP.Read_ASCS(ASCS)
