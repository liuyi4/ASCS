﻿import imageio
import os


class Dynamic_Image:

    def __init__(self,address,give_name):
        self.Address=address
        self.give_name=give_name
        self.run()


    #check whether file exist
    def Is_File_Exist(self,file_Name):
        return os.path.exists(file_Name)


    #get the file list
    def GetFileList(self,path,type):
        FileList=[]
        FindPath=path
        if self.Is_File_Exist(FindPath):
            FileNames=os.listdir(FindPath)
            for i in FileNames:
                if type in i:
                    temp=[]
                    temp.append(path+'\\'+i)
                    temp.append(int(i.split(type)[0]))
                    FileList.append(temp)

        FileList.sort(key=lambda x:x[1])
        print (FileList)
        return FileList


    def create_gif(self,address, gif_name):
 
        frames = []

        image_list=self.GetFileList(address,'.')
        for image_name in image_list:
            frames.append(imageio.imread(image_name[0]))
        # Save them as frames into a gif 
        imageio.mimsave("DResult\\"+gif_name, frames, 'GIF', duration = 0.5)
 
        return

    def run(self):
        self.create_gif(self.Address,self.give_name)


#address='VResult'
#save_name='created_gif.gif'

#address='DMap\\70MUX'
#save_name='70MUX.gif'

#address='DMap\\MUX37'
#save_name='37MUX.gif'

#address='DMap\\MUX20'
#save_name='20MUX.gif'

#address='DMap\\MUX11'
#save_name='11MUX.gif'


#address='DMap\\MUX6'
#save_name='6MUX.gif'


#address='DMap\\MAJ6'
#save_name='6MAJ.gif'


#address='DMap\\MAJ7'
#save_name='7MAJ.gif'

#address='DMap\\MAJ8'
#save_name='8MAJ.gif'

#address='DMap\\MAJ9'
#save_name='9MAJ.gif'

#address='DMap\\MAJ10'
#save_name='10MAJ.gif'

#address='DMap\\MAJ11'
#save_name='11MAJ.gif'

#address='DMap\\CAR6'
#save_name='CAR6.gif'

#address='DMap\\CAR8'
#save_name='CAR8.gif'

#address='DMap\\CAR10'
#save_name='CAR10.gif'

#address='DMap\\CAR12'
#save_name='CAR12.gif'


#address='VResult\\10CAR'
#save_name='CAR10.gif'


#address='VResult\\12CAR'
#save_name='CAR12.gif'


#address='VResult\\14CAR'
#save_name='CAR14.gif'


#address='VResult\\11MAJ'
#save_name='11MAJ.gif'


#address='VResult\\12MAJ'
#save_name='12MAJ.gif'


#address='VResult\\13MAJ'
#save_name='13MAJ.gif'



#address='VResult\\14MAJ'
#save_name='14MAJ.gif'



#address='VResult\\6MUX'
#save_name='6MUX.gif'


#address='VResult\\11MUX'
#save_name='11MUX.gif'


#address='VResult\\20MUX'
#save_name='20MUX.gif'

#address='VResult\\37MUX'
#save_name='37MUX.gif'


address='VResult\\70MUX'
save_name='70MUX.gif'


DI=Dynamic_Image(address,save_name)