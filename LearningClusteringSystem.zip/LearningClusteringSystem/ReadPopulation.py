﻿import os
from Rule import Rule001

class ReadPopulation_Visualization:
    def __init__(self,address):
       print("Begin for visualization")
       self.population=[]
       #self.Read(address)
       self.Read_Compact(address)
       #print(self.population)

    def Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        #print (information)
        return information

    def create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        return rule

    def Read(self,address):
        informations=self.Read_Information(address)
        for raw in informations:
            if("--->" in raw):
                extracted= raw.split(" : ")[0].split(" ---> ")
                action= int(extracted[-1])
                condition=extracted[0].split(" ")
                for i in range(0,len(condition)):
                    if condition[i]!='#':
                        condition[i]=int(condition[i])
                rule=self.create_rule(condition,action)
                #print(rule)
                self.population.append(rule)

    def Read_Compact(self,address):
        informations=self.Read_Information(address)
        for raw in informations:
            if ("  : " in raw):
                extracted=raw.split("\n")[0].split("  : ")
                action= int(extracted[-1])
                condition=extracted[0].split(" ")
                for i in range(0,len(condition)):
                    if condition[i]!='#':
                        condition[i]=int(condition[i])
                rule=self.create_rule(condition,action)
                #print(rule)
                self.population.append(rule)
#address="Result\\6_Prime_Population_2019_11_8_21_57_57.txt"
#RV=ReadPopulation_Visualization(address)


class ReadPopulation_ContinueTrain:
    def __init__(self,address,Is_Linux):
        self.IsLinux=Is_Linux
        self.Rule_Code=Rule001()
        self.population=[]
        self.Read(address)


    def Utilized_Address(self,address):
        if self.IsLinux:
            Address=os.getcwd()+'/LCUS/R_Population/'+address
        else:
            Address='R_Population\\'+address
        return Address


    def Read_Information(self,address):
        Address=self.Utilized_Address(address)
        read_information=open(Address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        #print (information)
        return information

    def Read(self,address):
        informations=self.Read_Information(address)
        for raw in informations:
            if("--->" in raw):
                enconds=raw.split(" : ")
                extracted= enconds[0].split(" ---> ")
                action= int(extracted[-1])
                condition=extracted[0].split(" ")
                for i in range(0,len(condition)):
                    if condition[i]!='#':
                        condition[i]=int(condition[i])
                parameters=enconds[1].split(" ")
                #print(parameters[2],parameters[5],parameters[8], parameters[11])
                rule=self.Rule_Code.Create_new_Single_Rule(condition,action,0)
                #numerosity
                rule[2]=int(parameters[2])
                if int(parameters[5])>0:
                    rule[3]=1
                if int(parameters[8])>0:
                    rule[4]=1
                print( rule)
                self.population.append(rule)
  
class ReadPopulation_UCS:
    def __init__(self,address):
       print("Begin for visualization")
       self.population=[]
       self.Read(address)

       #print(self.population)

    def Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        #print (information)
        return information

    def create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        return rule

    def Read(self,address):
        informations=self.Read_Information(address)
        for raw in informations:
            if("->" in raw):
                extracted= raw.split(" ->")
                action= int(extracted[1].split(' ')[0])
                condition=extracted[0].split(" ")
                for i in range(0,len(condition)):
                    if condition[i]!='#':
                        condition[i]=int(condition[i])
                rule=self.create_rule(condition,action)
                #print(rule)
                self.population.append(rule)



class ReadPopulation_XCS:
    def __init__(self,address):
       print("Begin for visualization")
       self.population=[]
       self.Read(address)
       #self.Read_Compact(address)
       #print(self.population)

    def Read_Information(self,address):
        read_information=open(address,'r')
        information=[]
        for lines in read_information:
            if lines != '' and lines !='\n':
             information.append(lines)
        #print (information)
        return information

    def create_rule(self,condition,action):
        rule=[]
        rule.append(condition)
        rule.append(action)
        return rule

    def Read(self,address):
        informations=self.Read_Information(address)
        for raw in informations:
            if(" ---->" in raw):
                extracted= raw.split(" ---->")[0].split(" : ")
                action= int(extracted[1])
                condition=extracted[0]
                r_condition=[]
                for i in condition:
                    if i!='#':
                        r_condition.append(int(i))
                    else:
                        r_condition.append('#')
                rule=self.create_rule(r_condition,action)
                #print(rule)
                self.population.append(rule)



#address='11_MUX_Population_2019_12_11_21_34_37.txt'
#RC=ReadPopulation_ContinueTrain(address,False)