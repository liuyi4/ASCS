﻿from ReadPopulation import ReadPopulation_Visualization
from ReadPopulation import ReadPopulation_UCS
from ReadPopulation import ReadPopulation_XCS


import numpy as np
import random
from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import os
import matplotlib.lines as mlines
import matplotlib as mpl
import copy
import os



#translate rules to patterns
class Value_knowledge:
    def __init__(self,address,action_list):


        Read_Pop=ReadPopulation_Visualization(address)
        #Read_Pop=ReadPopulation_UCS(address)
        #Read_Pop=ReadPopulation_XCS(address)

        self.action_list=action_list

        self.Raw_Population=Read_Pop.population

        self.clustered=self.Conver_to_Cluster()

        #for attribute importance
        #self.attribute_List=self.Calculate_Attribute_importance_distribution_Value()

        #for attribute value
        #self.attribute_List=self.Calculate_Attribute_importance_distribution_PureImportance()

        
        
    def Conver_to_Cluster(self):
        length=len(self.Raw_Population[0][0])
        cluster=[]
        for i in range(0,length+1):
            temp=[]
            cluster.append(temp)

        for rule in self.Raw_Population:
            level=self.General_Level(rule[0])
            cluster[level].append(rule)

        return cluster


    def General_Level(self,condition):
        count=0
        for cod in condition:
            if cod=='#':
                count+=1
        return count

    def Calculate_Attribute_importance_distribution_Value(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.Raw_Population[0][0])
        #print len(self.negative_set)
        for i in range(0,len(self.clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list
        G_distribution_list=[]
        for i in range(0,len(self.action_list)):
            temp=copy.deepcopy(distribution_list)
            G_distribution_list.append(temp)

        G_count_list=copy.deepcopy(G_distribution_list)

        #Z_count_list=copy.deepcopy(G_distribution_list)

        #Z_distribution_list=copy.deepcopy(G_distribution_list)


        #print distribution_list
        for i in range(0,len(self.clustered)):
            if len(self.clustered[i])!=0:
                for rule in self.clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            if rule[1]==1:
                                G_distribution_list[rule[1]][i][cond_l]+=rule[0][cond_l]
                                G_count_list[rule[1]][i][cond_l]+=1

                            if rule[1]==0:
                                G_distribution_list[rule[1]][i][cond_l]+=rule[0][cond_l]-1
                                G_count_list[rule[1]][i][cond_l]+=1


                for d_l in range(0,length):
                    for action in self.action_list:
                        if G_count_list[action][i][d_l]!=0:
                            G_distribution_list[action][i][d_l]=1.0*G_distribution_list[action][i][d_l]/G_count_list[action][i][d_l]
                            #if G_distribution_list[action][i][d_l]==0:
                             #   G_distribution_list[action][i][d_l]=-1
        #print (G_distribution_list)
        #print len(distribution_list)



        return G_distribution_list


    def Calculate_Attribute_importance_distribution_PureImportance(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.Raw_Population[0][0])
        #print len(self.negative_set)
        for i in range(0,len(self.clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list
        G_distribution_list=[]
        for i in range(0,len(self.action_list)):
            temp=copy.deepcopy(distribution_list)
            G_distribution_list.append(temp)

        G_count_list=copy.deepcopy(G_distribution_list)

        #Z_count_list=copy.deepcopy(G_distribution_list)

        #Z_distribution_list=copy.deepcopy(G_distribution_list)


        #print distribution_list
        for i in range(0,len(self.clustered)):
            if len(self.clustered[i])!=0:
                for rule in self.clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[rule[1]][i][cond_l]+=1
                            G_count_list[rule[1]][i][cond_l]+=1
                        else:
                            G_count_list[rule[1]][i][cond_l]+=1


                for d_l in range(0,length):
                    for action in self.action_list:
                        if G_count_list[action][i][d_l]!=0:
                            G_distribution_list[action][i][d_l]=1.0*G_distribution_list[action][i][d_l]/G_count_list[action][i][d_l]
                            #if G_distribution_list[action][i][d_l]==0:
                            #    G_distribution_list[action][i][d_l]=-1
        print (G_distribution_list)
        #print len(distribution_list)



        return G_distribution_list


    def Calculate_Attribute_importance_distribution_PureImportance_NOACTION(self):
        
        #Initial the action based distribution list
        distribution_list=[]
        length=len(self.Raw_Population[0][0])
        #print len(self.negative_set)
        for i in range(0,len(self.clustered)):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list

        
        G_distribution_list=copy.deepcopy(distribution_list)


        G_count_list=copy.deepcopy(G_distribution_list)

        #Z_count_list=copy.deepcopy(G_distribution_list)

        #Z_distribution_list=copy.deepcopy(G_distribution_list)


        #print distribution_list
        for i in range(0,len(self.clustered)):
            if len(self.clustered[i])!=0:
                for rule in self.clustered[i]:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[i][cond_l]+=1
                            G_count_list[i][cond_l]+=1
                        else:
                            G_count_list[i][cond_l]+=1


                for d_l in range(0,length):
                        if G_count_list[i][d_l]!=0:
                            G_distribution_list[i][d_l]=1.0*G_distribution_list[i][d_l]/G_count_list[i][d_l]
                            #if G_distribution_list[action][i][d_l]==0:
                            #    G_distribution_list[action][i][d_l]=-1
        print (G_distribution_list)
        #print len(distribution_list)



        return G_distribution_list

class Value_Knowledge_Running:
    def __init__(self,path):
        self.png_path=path
        self.name=1
        print ("Start Value Knowledge Record")

    def Generate_Knowledge(self, population_0, population_1,length):
        #Initial the action based distribution list
        Rule_Number=[]
        for i in range(0,length+1):
            Rule_Number.append(0)


        distribution_list=[]
        #print len(self.negative_set)
        for i in range(0,length+1):
            temp=[]
            for j in range(0,length):               
                temp.append(0)
            distribution_list.append(temp)

        #Action distributed list

        
        G_distribution_list=copy.deepcopy(distribution_list)


        G_count_list=copy.deepcopy(G_distribution_list)

        for i in range(0,len(population_0.population)):
            if len(population_0.population[i].cluster)+len(population_1.population[i].cluster)!=0:
                Rule_Number[i]=(len(population_0.population[i].cluster)+len(population_1.population[i].cluster))*2
                for rule in population_0.population[i].cluster:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[i][cond_l]+=1
                            G_count_list[i][cond_l]+=1
                        else:
                            G_count_list[i][cond_l]+=1

                for rule in population_1.population[i].cluster:
                    for cond_l in range(0,length):
                        if rule[0][cond_l]!='#':
                            G_distribution_list[i][cond_l]+=1
                            G_count_list[i][cond_l]+=1
                        else:
                            G_count_list[i][cond_l]+=1

                for d_l in range(0,length):
                        if G_count_list[i][d_l]!=0:
                            G_distribution_list[i][d_l]=1.0*G_distribution_list[i][d_l]/G_count_list[i][d_l]
        print (G_distribution_list)
        print(Rule_Number)
        return G_distribution_list,Rule_Number


    def Drew_NOACT(self,distribution_list,R_number,accuracy,iteration):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray(distribution_list)
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i) +'('+ str(R_number[i])+')')
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        
        z_first=np.asarray( distribution_list)
        z=z_first.T

        y=[]

        for i in range(0,len(z[0])):
            y.append(i)



        for i in range(0,len(z)):
            x=[i]*len(z[i])
            if len(z)>20:


                ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j] !=0 and i%4==0:

                        ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[0])  
            else:
                ax1.plot(x, y, z[i], line_list[0], color=color_list[0],lw=2)
                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j]!=0:
                        ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[0])
 

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        ax1.set_title('Accuracy: '+ str(accuracy) +"  Iterations: "+str(iteration), fontsize=20)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)


        for angle in range(115, 117,1):
           ax1.view_init(10, angle)
           plt.draw()
           png_complete_name = self.png_path + str(self.name) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
           fig.savefig(png_complete_name)
           plt.pause(.001)
        self.name+=1
            #plt.pause(.001)

class Visualize_value_pattern:
    def __init__(self,address,action_list,path,MapID):
        self.action_list=action_list
        V_K=Value_knowledge(address,action_list)
        self.png_path=path
        if MapID==0:
            self.distribution_list=V_K.Calculate_Attribute_importance_distribution_Value()
            self.Drew()
        elif MapID==1:
            self.distribution_list=V_K.Calculate_Attribute_importance_distribution_PureImportance()
            self.Drew()
        elif MapID==2:
             self.distribution_list=V_K.Calculate_Attribute_importance_distribution_PureImportance_NOACTION() 
             self.Drew_NOACT()   

       
        #self.Drew_Real()
    def Rainbown_color(self,length):
        R=0xff
        G_begin=0x66
        B_begin=0x66
        step=G_begin//length
        color='#'
        colors=[]
        for i in range(0,length):
            #color=color+str(hex(R))+str(hex(B_begin+step*i))+str(hex(G_begin-step*i))
            color=color+self.translate_sixteen_string(R)+self.translate_sixteen_string(B_begin+step*i)+self.translate_sixteen_string(B_begin-step*i)
            colors.append(color)
            color='#'
        #for co in colors:
        #    print co
        return colors


    def translate_sixteen_string(self,value):
        if abs(value)<0x10:
            #print value, '           ', 0x10
            result='0'
            result=result+str(hex(value)).split('x')[-1]
        else:
         result=str(hex(value)).split('x')[-1]
        return result   


    def Detect_Inforative_levels(self,list):
         result=[]
         for i in range(0,len(list)):
             for j in list[i]:
                 if j!=0:
                    result.append(i)
                    break
         print result
         return result


    def Drew(self):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray( self.distribution_list[0])
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i))
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        for act in range(0,len(self.action_list)):
            important_list=self.Detect_Inforative_levels(self.distribution_list[act])
            z_first=np.asarray( self.distribution_list[act])
            z=z_first.T

            y=[]

            for i in range(0,len(z[0])):
                y.append(i)



            for i in range(0,len(z)):
                x=[i]*len(z[i])
                if len(z)>20:


                    ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j] !=0 and i%4==0:

                            ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[act])  
                else:
                    ax1.plot(x, y, z[i], line_list[act], color=color_list[act],lw=2)
                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j]!=0:
                            ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[act])
   
        



            
            #y=[]
            #count=0
            #for i in range(0,len(z_first[0])):
            #    y.append(i)
         
            #for level in important_list:
            #    x=[level]*len(z_first[level])
            #    n_z=z_first[level]
            
            #    ax1.plot( y, x,n_z, '--', color=color_list[count],lw=1,alpha=3)

                    
            #    ax1.scatter(y, x,n_z,color=color_list[count]) 
            #    count+=1
            #    if count>len(color_list):
            #        count=0

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        #ax1.set_title('6-BIT MUX', fontsize=30)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)


        #ax1.set_title('RCR 11-Bits MUX', fontsize=20)
        #ax1.set_title('RCR 10-Bits Carry', fontsize=20)
        #ax1.set_title('RCR 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('QRC 11-Bits MUX', fontsize=20)
        #ax1.set_title('QRC 10-Bits Carry', fontsize=20)
        #ax1.set_title('QRC 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('FU1 11-Bits MUX', fontsize=20)
        #ax1.set_title('FU1 10-Bits Carry', fontsize=20)
        #ax1.set_title('FU1 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('AFIM 20-Bits MUX', fontsize=20)
        #ax1.set_title('AFVM 20-Bits MUX', fontsize=20)
        #ax1.set_title('AFIM 37-Bits MUX', fontsize=20)
        #ax1.set_title('AFVM 37-Bits MUX', fontsize=20)
        #ax1.set_title('AFIM 70-Bits MUX', fontsize=20)
        #ax1.set_title('AFVM 70-Bits MUX', fontsize=20)


        #ax1.set_title('AFIM 10-Bits Carry', fontsize=20)
        #ax1.set_title('AFVM 10-Bits Carry', fontsize=20)
        #ax1.set_title('AFIM 12-Bits Carry', fontsize=20)
        #ax1.set_title('AFVM 12-Bits Carry', fontsize=20)
        #ax1.set_title('AFIM 14-Bits Carry', fontsize=20)
        #ax1.set_title('AFVM 14-Bits Carry', fontsize=20)


        #ax1.set_title('AFIM 7-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 7-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFIM 11-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 11-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFIM 13-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 13-Bits Majority-On', fontsize=20)


        #ax1.set_title('AFIM 8-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 8-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFIM 12-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 12-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFIM 14-Bits Majority-On', fontsize=20)
        #ax1.set_title('AFVM 14-Bits Majority-On', fontsize=20)
        """
        for angle in range(1, 370,5):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(angle) + ".png"
            #fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            #print(png_complete_name)
            fig.savefig(png_complete_name)
            plt.pause(.001)
        """

        #for angle in range(1, 370,5):
        for angle in range(115, 117,1):
            #115, 117,1
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(angle) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            fig.savefig(png_complete_name)
            plt.pause(.001)


    def Drew_Single(self):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray( self.distribution_list[0])
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i))
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        for act in range(0,len(self.action_list)):
            important_list=self.Detect_Inforative_levels(self.distribution_list[act])
            z_first=np.asarray( self.distribution_list[act])
            z=z_first.T

            y=[]

            for i in range(0,len(z[0])):
                y.append(i)



            for i in range(0,len(z)):
                x=[i]*len(z[i])
                if len(z)>20:


                    ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j] !=0 and i%4==0:

                            ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[act])  
                else:
                    ax1.plot(x, y, z[i], line_list[act], color=color_list[act],lw=2)
                    ax1.legend()
                    for j in range(0,len(z[i])):
                        if z[i][j]!=0:
                            ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[act])
   
        



            
            #y=[]
            #count=0
            #for i in range(0,len(z_first[0])):
            #    y.append(i)
         
            #for level in important_list:
            #    x=[level]*len(z_first[level])
            #    n_z=z_first[level]
            
            #    ax1.plot( y, x,n_z, '--', color=color_list[count],lw=1,alpha=3)

                    
            #    ax1.scatter(y, x,n_z,color=color_list[count]) 
            #    count+=1
            #    if count>len(color_list):
            #        count=0

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        #ax1.set_title('6-BIT MUX', fontsize=30)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)

        """
        for angle in range(1, 370,5):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(angle) + ".png"
            #fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            #print(png_complete_name)
            fig.savefig(png_complete_name)
            plt.pause(.001)
        """

        for angle in range(116, 117,1):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(name) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            fig.savefig(png_complete_name)
            plt.pause(.001)
        self.name+=1

    def Drew_NOACT(self):
        fig=plt.figure(figsize=(10, 10), dpi=150)
        ax1=fig.add_subplot(111,projection='3d')
        z_first=np.asarray( self.distribution_list)
        z=z_first.T


        
        xlabels_t=[]       
        for i in range(0,len(z)):
            xlabels_t.append(str(i))
        xlabels=np.array(xlabels_t)
        xpos=np.arange(xlabels.shape[0])

        ylabels_t=[]       
        for i in range(0,len(z[0])):
            ylabels_t.append(str(i))
        ylabels=np.array(ylabels_t)
        ypos=np.arange(ylabels.shape[0])



        xposM, yposM=np.meshgrid(xpos,ypos,copy=False)

        dx=0.3
        dy=0.1

        ax1.w_xaxis.set_ticks(xpos + dx/2.)
        ax1.w_xaxis.set_ticklabels(xlabels)

        ax1.w_yaxis.set_ticks(ypos + dy/3.)
        ax1.w_yaxis.set_ticklabels(ylabels)

        color_list=['#EE7700','DarkGreen', 'Blue', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan','tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple', 'tab:brown', 'tab:pink', 'tab:gray', 'tab:olive', 'tab:cyan']

        line_list=['--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':','--',':']
        #for act in range(6,7):
        
        important_list=self.Detect_Inforative_levels(self.distribution_list)
        z_first=np.asarray( self.distribution_list)
        z=z_first.T

        y=[]

        for i in range(0,len(z[0])):
            y.append(i)



        for i in range(0,len(z)):
            x=[i]*len(z[i])
            if len(z)>20:


                ax1.plot(x, y, z[i], line_list[act],color=color_list[act],lw=3,alpha=3)

                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j] !=0 and i%4==0:

                        ax1.text(i, j, z[i][j]+0.1, str(round(z[i][j],2)), color=color_list[0])  
            else:
                ax1.plot(x, y, z[i], line_list[0], color=color_list[0],lw=2)
                ax1.legend()
                for j in range(0,len(z[i])):
                    if z[i][j]!=0:
                        ax1.text(i, j, z[i][j]+0.01, str(round(z[i][j],2)), color=color_list[0])
 

            
                       


        ax1.set_xlabel('X ', fontsize=20)
        ax1.set_ylabel('Y', fontsize=20)
        ax1.set_zlabel("Z", fontsize=20)


        #ax1.set_title('ASCS 11-Bits MUX', fontsize=20)
        #ax1.set_title('ASCS 12-Bits Carry', fontsize=20)
        #ax1.set_title('ASCS 13-Bits Majority-On', fontsize=20)


        #ax1.set_title('XCS 11-Bits MUX', fontsize=20)
        #ax1.set_title('XCS 12-Bits Carry', fontsize=20)
        #ax1.set_title('XCS 13-Bits Majority-On', fontsize=20)


        #ax1.set_title('UCS 11-Bits MUX', fontsize=20)
        #ax1.set_title('UCS 12-Bits Carry', fontsize=20)
        #ax1.set_title('UCS 13-Bits Majority-On', fontsize=20)


        #ax1.set_title('RCR 11-Bits MUX', fontsize=20)
        #ax1.set_title('RCR 10-Bits Carry', fontsize=20)
        #ax1.set_title('RCR 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('QRC 11-Bits MUX', fontsize=20)
        #ax1.set_title('QRC 10-Bits Carry', fontsize=20)
        #ax1.set_title('QRC 11-Bits Majority-On', fontsize=20)


        #ax1.set_title('FU1 11-Bits MUX', fontsize=20)
        #ax1.set_title('FU1 10-Bits Carry', fontsize=20)
        #ax1.set_title('FU1 11-Bits Majority-On', fontsize=20)

        #ax1.set_title('Hidden 14+6-Bits Carry', fontsize=20)
        #ax1.set_title('Hidden 3+14+3-Bits Carry', fontsize=20)
        #ax1.set_title('Hidden 6+14-Bits Carry', fontsize=20)

        #ax1.set_title('Hidden 13+7-Bits Majority-On', fontsize=20)
        #ax1.set_title('Hidden 7+13-Bits Majority-On', fontsize=20)
        #ax1.set_title('Hidden 4+13+3-Bits Majority-On', fontsize=20)
        

        #ax1.set_title('Hidden 14+6-Bits Multiplexer', fontsize=20)
        #ax1.set_title('Hidden 6+14-Bits Multiplexer', fontsize=20)
        #ax1.set_title('Hidden 2+14+4-Bits Multiplexer', fontsize=20)


        #ax1.set_title('Natural Solution', fontsize=20)
        #ax1.set_title('N-ORC', fontsize=20)
        #ax1.set_title('Butz\'s solution', fontsize=20)

        ax1.set_title('FIM 10-Bits Carry', fontsize=20)

        #for angle in range(115, 117,1):
        for angle in range(293, 295,1):
            ax1.view_init(30, angle)
            plt.draw()
            png_complete_name = self.png_path + str(angle) + ".png"
            # fig.savefig(png_complete_name, dpi=(400))
            #fig.savefig(png_complete_name,bbox_inches='tight')
            fig.savefig(png_complete_name)
            plt.pause(.001)

#Address=address="Result\\6_Prime_Population_2019_11_8_21_57_57.txt"
#Address=address="Result\\5_Prime_Population_2019_11_8_22_19_47.txt"
#Address=address="Result\\7_Prime_Population_2019_11_8_22_2_34.txt"
#Address=address="Result\\10_HiddenMUX_Population_2019_11_12_22_1_48.txt"
#Address=address="Result\\6_MUX_Population_2019_12_11_20_34_21.txt"

#Address=address="V_Pop\\14_Carry_Population_2020_1_11_13_4_6.txt"
#Path="VResult\\14CAR\\"

#Address=address="V_Pop\\13_Majority_Population_2019_12_30_12_39_36.txt"
#Path="VResult\\13MAJ\\"


#Address=address="V_Pop\\14_Majority_Population_2020_1_15_2_38_49.txt"
#Path="VResult\\14MAJ\\"


#Address=address="V_Pop\\MUX702019_7_22_19_32_7.txt"
#Path="VResult\\70MUX\\"


#Address=address="V_Pop\\MUX62019_7_10_17_27_20.txt"
#Path="VResult\\6MUX\\"


#Address=address="V_Pop\\Majority72019_7_11_6_21_52.txt"
#Path="VResult\\7MAJ\\"

#Address=address="V_Pop\\6_Carry_Population_2020_1_23_1_20_43.txt"
#Path="VResult\\6CAR\\"



#Address=address="V_Pop\\20_HiddenMaj_Population_2020_1_23_22_32_20.txt"
#Path="VResult\\12HMAJ\\"


#Address=address="V_Pop\\20_HiddenMaj_Population_2020_1_23_22_55_51.txt"
#Path="VResult\\11HMAJ\\"


#Address=address="V_Pop\\20_HiddenMUX_Population_2020_1_23_23_2_55.txt"
#Path="VResult\\11HMUX\\"

#Address=address="V_Pop\\20_HiddenCarry_Population_2020_1_23_23_26_34.txt"
#Path="VResult\\11HCAR\\"


#Address=address="V_Pop\\10_Carry_Population_2020_1_11_2_46_59.txt"
#Path="VResult\\10CAR\\"


#Address=address="V_Pop\\12_Carry_Population_2020_1_13_18_51_48.txt"
#Path="VResult\\12CAR\\"


#Address=address="V_Pop\\UCS\\Carry_12_2020_1_13_5_28_5.txt"
#Path="VResult\\U12CAR\\"

#Address=address="V_Pop\\14_Carry_Population_2020_1_11_13_4_6.txt"
#Path="VResult\\U14CAR\\"

#Address=address="V_Pop\\UCS\\Carry_10_2020_1_11_1_20_55.txt"
#Path="VResult\\U10CAR\\"


#Address=address="V_Pop\\UCS\\Carry_10_2020_1_11_1_20_55.txt"
#Path="VResult\\U10CAR\\"


#Address=address="V_Pop\\XCS\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_612269e7_d4da_4549_b9fb_909e06d8d3d1Problem_carryPlength_10FTime_DAY__2020_01_10__Time__22___48___32.txt"
#Path="VResult\\X10CAR\\"


#Address=address="V_Pop\\XCS\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_0c88186b_bf8d_48b4_9b68_061fb8233e79Problem_carryPlength_12FTime_DAY__2020_01_13__Time__02___42___03.txt"
#Path="VResult\\X12CAR\\"


#Address=address="V_Pop\\XCS\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_4bb719fa_8e3f_4e2b_a151_c8c5d6fb5671Problem_carryPlength_14FTime_DAY__2020_01_16__Time__07___45___55.txt"
#Path="VResult\\X14CAR\\"



#Address=address="V_Pop\\XCS\\Carry10QRC2020_1_30_19_28_29.txt"
#Path="VResult\\XC10CAR\\"






#Address=address="V_Pop\\UCS\\Carry_14_2020_1_30_22_42_14.txt"
#Path="VResult\\U14CAR\\"


#Address=address="V_Pop\\MUX11RCR2019_7_11_5_58_34.txt"
#Path="VResult\\11MUX\\"



#Address=address="V_Pop\\MUX20RCR2019_7_12_15_2_49.txt"
#Path="VResult\\20MUX\\"


#Address=address="V_Pop\\MUX37RCR2019_7_13_6_32_10.txt"
#Path="VResult\\37MUX\\"



#Address=address="V_Pop\\12_Majority_Population_2019_12_14_9_27_21.txt"
#Path="VResult\\12MAJ\\"


#Address=address="V_Pop\\Majority11RCR32019_8_1_21_28_10.txt"
#Path="VResult\\11MAJ\\"

#0 AFVM  1 AFIM 2FIM
#Address="V_Pop\\MUX6RCR2019_7_10_17_27_20.txt"
#Path="OVR\\6MUX_AFIM\\"
#Path="OVR\\6MUX_AFVM\\"
#Path="OVR\\6MUX_FIM\\"


#Address="V_Pop\\ASCS\\11_MUX_Population_2020_1_15_11_5_17.txt"
#Path="OVR\\11ASCS_MUX\\"

#Address="V_Pop\\ASCS\\12_Carry_Population_2020_1_13_19_45_17.txt"
#Path="OVR\\12ASCS_CAR\\"

#Address="V_Pop\\ASCS\\13_Majority_Population_2019_12_30_15_55_49.txt"
#Path="OVR\\13ASCS_MO\\"


#Address="V_Pop\\XCS\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_2a8c9d7f_c67c_4764_ade2_7d21f6d4eb26Problem_multiplexerPlength_11FTime_DAY__2020_01_10__Time__01___09___23.txt"
#Path="OVR\\11XCS_MUX\\"

#Address="V_Pop\\XCS\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_0c88186b_bf8d_48b4_9b68_061fb8233e79Problem_carryPlength_12FTime_DAY__2020_01_13__Time__02___42___03.txt"
#Path="OVR\\12XCS_CAR\\"

#Address="V_Pop\\XCS\\XCS_45598a9f_15e3_4393_b4e4_da00bc199dfdAgent_1b9d0095_711d_4a4f_9a75_7baea46c2bc7Problem_majorityOnPlength_13FTime_DAY__2020_01_17__Time__02___16___08.txt"
#Path="OVR\\13XCS_MO\\"


#Address="V_Pop\\UCS\\MUX_11_2020_1_9_20_19_50.txt"
#Path="OVR\\11UCS_MUX\\"

#Address="V_Pop\\UCS\\Carry_12_2020_1_13_5_28_5.txt"
#Path="OVR\\12UCS_CAR\\"

#Address="V_Pop\\UCS\\Majority_13_2019_12_30_4_59_39.txt"
#Path="OVR\\13UCS_MO\\"


#Address="V_Pop\\RCR\\MUX11RCR2019_7_11_5_58_34.txt"
#Path="OVR\\RCR_MUX\\"

#Address="V_Pop\\RCR\\Carry10RCR32019_7_13_3_15_47.txt"
#Path="OVR\\RCR_CAR\\"

#Address="V_Pop\\RCR\\Majority11RCR32019_8_1_21_28_10.txt"
#Path="OVR\\RCR_MO\\"


#Address="V_Pop\\QRC\\MUX11QRC2019_7_11_5_57_40.txt"
#Path="OVR\\QRC_MUX\\"

#Address="V_Pop\\QRC\\Carry10QRC2019_7_13_3_13_13.txt"
#Path="OVR\\QRC_CAR\\"

#Address="V_Pop\\QRC\\Majority11QRC2019_7_21_20_50_4.txt"
#Path="OVR\\QRC_MO\\"


#Address="V_Pop\\FU1\MUX11FU12019_7_10_18_27_42.txt"
#Path="OVR\\FU_MUX\\"

#Address="V_Pop\\FU1\\Carry10FU12019_7_12_12_4_51.txt"
#Path="OVR\\FU_CAR\\"

#Address="V_Pop\\FU1\\Majority11FU12019_7_16_16_44_10.txt"
#Path="OVR\\FU_MO\\"


#Address="V_Pop\\MUX\\MUX20RCR2019_7_12_15_2_49.txt"
#Path="OVR\\VR\\20MUX_I\\"
#Path="OVR\\VR\\20MUX_V\\"

#Address="V_Pop\\MUX\\MUX37RCR2019_7_13_6_32_10.txt"
#Path="OVR\\VR\\37MUX_I\\"
#Path="OVR\\VR\\37MUX_V\\"



#Address="V_Pop\\MUX\\MUX702019_7_22_19_32_7.txt"
#Path="OVR\\VR\\70MUX_I\\"
#Path="OVR\\VR\\70MUX_V\\"


#Address="V_Pop\\CAR\\10_Carry_Population_2020_1_11_2_46_59.txt"
#Path="OVR\\VR\\10CAR_I\\"
#Path="OVR\\VR\\10CAR_V\\"


#Address="V_Pop\\CAR\\12_Carry_Population_2020_1_13_18_51_48.txt"
#Path="OVR\\VR\\12CAR_I\\"
#Path="OVR\\VR\\12CAR_V\\"


#Address="V_Pop\\CAR\\14_Carry_Population_2020_1_11_13_4_6.txt"
#Path="OVR\\VR\\14CAR_I\\"
#Path="OVR\\VR\\14CAR_V\\"


#Address="V_Pop\\MOO\\Majority7RCR2019_7_11_6_21_52.txt"
#Path="OVR\\VR\\7MO_I\\"
#Path="OVR\\VR\\7MO_V\\"


#Address="V_Pop\\MOO\\Majority11RCR32019_8_1_21_28_10.txt"
#Path="OVR\\VR\\11MO_I\\"
#Path="OVR\\VR\\11MO_V\\"


#Address="V_Pop\\MOO\\13_Majority_Population_2019_12_30_12_39_36.txt"
#Path="OVR\\VR\\13MO_I\\"
#Path="OVR\\VR\\13MO_V\\"

#Address="V_Pop\\MOE\\Majority8RCR2019_7_12_4_40_45.txt"
#Path="OVR\\VR\\8MO_I\\"
#Path="OVR\\VR\\8MO_V\\"

#Address="V_Pop\\MOE\\12_Majority_Population_2019_12_14_9_27_21.txt"
#Path="OVR\\VR\\12MO_I\\"
#Path="OVR\\VR\\12MO_V\\"

#Address="V_Pop\\MOE\\14_Majority_Population_2020_1_15_2_38_49.txt"
#Path="OVR\\VR\\14MO_I\\"
#Path="OVR\\VR\\14MO_V\\"

#Address="V_Pop\\H\\20_HiddenCarry_Population_2020_1_23_23_26_34H.txt"
#Path="OVR\\HIDDEN\\CARF\\"

#Address="V_Pop\\H\\20_HiddenCarry_Population_2020_1_23_23_26_34.txt"
#Path="OVR\\HIDDEN\\CARM\\"

#Address="V_Pop\\H\\20_HiddenCarry_Population_2020_1_23_23_26_34L.txt"
#Path="OVR\\HIDDEN\\CARL\\"


#Address="V_Pop\\H\\Majority7RCR2019_7_11_6_21_52H.txt"
#Path="OVR\\HIDDEN\\MOF\\"

#Address="V_Pop\\H\\Majority7RCR2019_7_11_6_21_52L.txt"
#Path="OVR\\HIDDEN\\MOL\\"

#Address="V_Pop\\H\\20_HiddenMaj_Population_2020_1_23_22_55_51.txt"
#Path="OVR\\HIDDEN\\MOM\\"


#Address="V_Pop\\H\\MUX62019_7_10_17_27_20H.txt"
#Path="OVR\\HIDDEN\\MUXF\\"

#Address="V_Pop\\H\\MUX62019_7_10_17_27_20L.txt"
#Path="OVR\\HIDDEN\\MUXL\\"


#Address="V_Pop\\H\\20_HiddenMUX_Population_2020_1_23_23_2_55.txt"
#Path="OVR\\HIDDEN\\MUXM\\"

#Address="V_Pop\\6_MUX\\MUX6RCR22019_7_10_17_27_21.txt"
#Path="OVR\\6MUX\\N\\"

#Address="V_Pop\\6_MUX\\MUX62019_7_10_17_27_20.txt"
#Path="OVR\\6MUX\\N_ORC\\"

#Address="V_Pop\\6_MUX\\MUX6RCR2.txt"
#Path="OVR\\6MUX\\B\\"

#Address=address="V_Pop\\RCR\\Carry10RCR32019_7_13_3_15_47.txt"
#Path="VResult\\"

#action_list=[0,1]
#vvp=Visualize_value_pattern(Address,action_list,Path,2)