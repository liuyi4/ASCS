﻿from Rule import *
from Cluster import Cluster
import random


class population:
    #PN_State: a value that identify the population's objective (completely correct map or completely incorrect map)
    #PN_State==True: completely correct map
    #PN_State==False: completely incorrect map

    #attribute_number: number of the involved attributes 
    def __init__(self, PN_State, attribute_number, action,search_Number,possible_value_list,number_action,max,min):

        self.PN_State=PN_State

        self.numer_action=number_action


        self.Attribute_Number=attribute_number


        self.support_act=action


        self.Maximum_SearchNumber=search_Number

        #Attribute value list
        self.Possible_Value_List=possible_value_list


        #A population involve a set of cluster, a cluster is a sub search space of the exploring domain
        self.population=[]
        self.Initial_Population()
        self.Activate_Cluster()

        #the explorable clusters in this population
        self.Explorable_List=self.Get_explorable_Clusters_ID()


        #posibility of utlize the priority of maximum general [0,1]
        self.P_General=0.8


        #number of rules in this population
        self.numRules=0

        self.Set_Searchable_Clusters(max,min)
        
        
    #Initial the clusters in the population
    def Initial_Population(self):
            for i in range(0,self.Attribute_Number+1):
                cluster_ini=Cluster(i)
                self.population.append(cluster_ini)
                self.Initial_Space_Possible_rules(cluster_ini,i)




    def Activate_Cluster(self):
        for cluster in self.population:
            cluster.numAbsumptionRemoved.append(0)
            cluster.numSumptionRemoved.append(0)
            cluster.numEvolved.append(0)
            cluster.Out_numAbsumptionRemoved.append(0)
            cluster.Out_numSumptionRemoved.append(0)



    def Get_explorable_Clusters_ID(self):
        ID_List=[]
        for i in range(0,len(self.population)):
            if self.population[i].Active==True:
                ID_List.append(i)



    def Set_Searchable_Clusters(self, max, min):
        for i in range(0,len(self.population)):
            if i>max or i<min:
                self.population[i].Active=False


    #return the highest general level if a sub search space is visitable
    def Get_General_Level_Priority_general(self):
        for i in range(len(self.population)-1,-1,-1):
            if self.population[i].Active==True:
                return i


    def Initial_Space_Possible_rules(self,cluster,general_level):
        result=1*self.numer_action
        for ID in range(0,self.Attribute_Number-general_level):
            result*=self.Possible_Value_List[ID]
        #print(result)
        cluster.Space_Possible_Rules=result

    #return the space with the highest number of rules
    def Get_General_Level_Priority_prosperous(self,general_level):
        max_value=(self.population[general_level].numEvolved[-1]-self.population[general_level].numAbsumptionRemoved[-1]-self.population[general_level].numSumptionRemoved[-1])*general_level
        max_Id=general_level
        for i in range(general_level+1,len(self.population)):
            current_value=(self.population[i].numEvolved[-1]-self.population[i].numAbsumptionRemoved[-1]-self.population[i].numSumptionRemoved[-1])*general_level
            if current_value>=max_value:
                max_Id=i
                max_value=current_value
        return max_Id


    def Produce_Search_General(self, general_level):
        #if(random.random()<self.P_General):
        out_general_level= self.Get_General_Level_Priority_general()
             #When all search space has been closed
        if out_general_level==None:
              return self.Attribute_Number
        return out_general_level
                   
        #else:
        #     return self.Get_General_Level_Priority_prosperous(general_level)
