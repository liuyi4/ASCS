#pragma once;
using namespace std;
#include <vector>;
#include "Rule_001.h";
#include <time.h>;

class Rule001_Oper {
public:
	//initial this class need the length of the problem
	Rule001_Oper(int problem_length);


	//Create a new rule
	Rule_001 CreateRule(int general_level, std::vector<string> state);


	//Judge whether this rule can match an instance (state)
	bool IsConditionMatch(std::vector<string> &state, std::vector<string> &condition);


	//asscert whether this rule belong to the absumption list meanwhile update the training parameters for the rules in informed list
	bool IsAbsumptionAndUpdate(Rule_001 &rule, int &realAction, int &populationAction, bool &PNstate);


	//create a new rule by absumption by correct one mistaken
	Rule_001 AbRule(std::vector<string> &state, Rule_001 rule, int &generalizationlevel);


	//asscert whether two conditions are equal
	bool SameCondition(std::vector<string> &old_condition, std::vector<string> &new_condition);

	//asscert whether old condition can subsume new condition
	bool SubsumeCondition(std::vector<string> &old_condition, std::vector<string> &new_condition);

	//asscert whether two conditions have overlapping
	bool OverlapCondition(std::vector<string> &condition1, std::vector<string> &condition2);

	//Generated an Inform Rule
	Rule_001 InformRule(Rule_001 rule, int &generalizationlevel);

	//the problem length
	int PL;

private:
	//the attribute list
	std::vector<int> AL{};

	

	int seed = (unsigned)time(NULL);


};
