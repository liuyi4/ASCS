
using namespace std;
#include <vector>;
#include "ASCS_Cluster.h";
#include "ASCS_Population.h";

ASCS_Population::ASCS_Population(bool pnstate, int action)
{
	// 0: negative 1:positive
	ASCS_Population::PN_state = pnstate;
	ASCS_Population::Action = action;
}