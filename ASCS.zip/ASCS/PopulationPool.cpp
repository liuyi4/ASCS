using namespace std;
#include <vector>;
#include "ASCS_Cluster.h";
#include"PopulationPool.h";
#include<map>;
#include <iostream>;
#include <string>;
#include "TrainingMechanism.h";
#include "MatchList.h";
#include <iostream>;
#include <ctime>;
#include <fstream>;
#include "BooleanEnvironment.h";
#include "Config.h";
#include "CompactionMechanism.h";




PopulationPool::PopulationPool()
{

}


//update the cluster, this algorithm is invoked in each epoch except the first epoch
void PopulationPool::Reforged_Cluster(ASCS_Cluster &useCluster)
{
	useCluster.C_Aubsumed_num.push_back(0);

	useCluster.C_Subsumed_num.push_back(0);

	useCluster.C_Error_num.push_back(0);

	useCluster.T_Aubsumed_num.push_back(0);

	useCluster.T_Subsumed_num.push_back(0);

	useCluster.T_Evolved_num.push_back(0);

	useCluster.T_Cov_num.push_back(0);
}


//initial the population pool
std::vector<ASCS_Population> PopulationPool::initial_Population_Pool(int &problem_length, vector<int> &action_list)
{

	//population pool
	std::vector<ASCS_Population> Population_Pool;

	for (int i=0; i<action_list.size();++i)
	{
		//std::cout << i << std::endl;
		//std::cout << action_list[i] << std::endl;
		//for the negative populations
		//positive :1 ; negative 0

		//ASCS_Population N_P(false, action_list[i]);
		//PopulationPool::link_clusters(problem_length, N_P);
		//PopulationPool::SetInitialHighest_Generalization(N_P);
		//Population_Pool.push_back(N_P);

		ASCS_Population P_P(true, action_list[i]);
		PopulationPool::link_clusters(problem_length, P_P);
		PopulationPool::SetInitialHighest_Generalization(P_P);
		//check the population's generalization level
		//std::cout << P_P.Generalization_Level << std::endl;
		
		
		Population_Pool.push_back(P_P);
		
	}

	return Population_Pool;
}


//initial the clusters in a population
void PopulationPool::link_clusters(int &problem_length, ASCS_Population &population)
{
	for (int i = 0; i<problem_length+1; ++i)
	{
		//std::cout << i << std::endl;
		ASCS_Cluster cluster;
		population.Clusters.push_back(cluster);
	}
}


//initial the population generalization level
void PopulationPool::SetInitialHighest_Generalization(ASCS_Population &population)
{
	for (int i = population.Clusters.size()-1; i > -1; --i)
	{
		if (population.Clusters[i].Active == true)
		{
			population.Generalization_Level = i;
			return;
		}
	}
}


//find the highest valuable searchspace for the evolving process
void PopulationPool::SetHighest_Generalization(ASCS_Population &population)
{
	for (int i = population.Clusters.size() - 1; i > -1; --i)
	{
		if (population.Clusters[i].Rules.size()>0)
		{
			if (i != population.Clusters.size() - 1)
			{
				population.Generalization_Level = i+1;
				return;
			}
			else
			{
				population.Generalization_Level = i;
				return;
			}
		}
	}
}


//print the trained popuation
void PopulationPool::Print_Population(std::vector<ASCS_Population> &Populations)
{
	for (int p = 0; p < Populations.size(); ++p)
	{
		std::cout << "P:"<<p <<"   "<< "A:"<<Populations[p].Action<<" "<<"PN:"<< Populations[p].PN_state<<" "<<"Rnum:"<< Populations[p].num_Rules<< std::endl;
		std::cout <<"==================================================================" << std::endl;
		//Cluster ID
		for (int c =Populations[p].Clusters.size()-1; c>-1;--c)
		{
			//if (Populations[p].Clusters[c].Rules.size() > 0)
			//{
				std::cout << "C:" << c << " " << "TA:" << Populations[p].Clusters[c].T_Aubsumed_num.back() << " "
					<< "TS:" << Populations[p].Clusters[c].T_Subsumed_num.back() << " " << "TE:" << Populations[p].Clusters[c].T_Evolved_num.back() << " "
					<< "CA:" << Populations[p].Clusters[c].C_Aubsumed_num.back() << " " << "CS:" << Populations[p].Clusters[c].C_Subsumed_num.back() << " "
					<< "CE"  << Populations[p].Clusters[c].C_Error_num.back() <<"  State: "<< Populations[p].Clusters[c].Active
					<< std::endl;
				std::cout << "==================================================================" << std::endl;
				//Rule ID
				for (int r = 0; r < Populations[p].Clusters[c].Rules.size(); ++r)
				{

					//if (R_O.IsAbsumptionAndUpdate(Populations[p].Clusters[c].Rules[r], I_Action, Populations[p].Action, Populations[p].PN_state))
					for (int i = 0; i < Populations[p].Clusters[c].Rules[r].condition.size(); ++i)
					{
						std::cout << Populations[p].Clusters[c].Rules[r].condition[i];
					}
					std::cout << " : " << Populations[p].Action << "    P:"<< Populations[p].Clusters[c].Rules[r].P_p<<
						"  N:"<< Populations[p].Clusters[c].Rules[r].N_p << "  state: "<< Populations[p].Clusters[c].Rules[r].Sub_state
						<<std::endl;

					//PopulationPool::Print_GeneralLevel(Populations[p].Clusters[c].Rules[r]);

				}
			//}

		}

		std::cout << std::endl;
		std::cout << std::endl;
		std::cout << std::endl;
	}
}


//check the attribute list
void PopulationPool::Print_GeneralLevel(Rule_001 &rule)
{
	for (int i = 0; i < rule.Attributelist.size(); ++i)
	{
		std::cout << rule.Attributelist[i];
	}
	std::cout << std::endl;
}


//Print the MatchList
void PopulationPool::Print_MatchSet(MatchList &ML)
{
	std::cout << "Absumption List " << std::endl;
	for (int i = 0; i < ML.Absumption_L.size(); ++i)
	{
		for (int j = 0; j < ML.Absumption_L[i].size(); ++j)
		{
			std::cout << ML.Absumption_L[i][j] << " ";
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;

	std::cout << "Informed List " << std::endl;
	for (int i = 0; i < ML.Informed_L.size(); ++i)
	{
		for (int j = 0; j < ML.Informed_L[i].size(); ++j)
		{
			std::cout << ML.Informed_L[i][j] << " ";
		}
		std::cout << std::endl;
	}
}


//get the complete time
string PopulationPool::GetTime()
{
	time_t now = time(0);
	
	tm Ptm;
	localtime_s(&Ptm, &now);

	string C_Time;
	 
	C_Time = to_string(Ptm.tm_year+1900) + "_" + to_string(Ptm.tm_mon+1) + "_" + to_string(Ptm.tm_mday) + "_" +to_string(Ptm.tm_hour)+"_"+ to_string(Ptm.tm_min)+"_"+to_string(Ptm.tm_sec);

	std::cout << "Complete:";
	std::cout << C_Time << std::endl;

	return C_Time;
}


//set the generalization level for search and 
void PopulationPool::UpdateSearchSpace(std::vector<ASCS_Population> &populations)
{
	for (int p = 0; p < populations.size(); ++p)
	{
		PopulationPool::SetInitialHighest_Generalization(populations[p]);
		for (int c = 0; c < populations[p].Clusters.size(); ++c)
		{
			PopulationPool::Reforged_Cluster(populations[p].Clusters[c]);
		}
	}
}


//generate the file name for storing the result
string PopulationPool::Generate_File_Name(Config &cof, BooleanEnvironment &env)
{
	string name = PopulationPool::GetTime();

	name += "_" + to_string(cof.problem_length) + "_" + env.ProblemName[cof.problem_Id]+".txt";

	//cout << name << endl;
	return name;
}


//save the result
void PopulationPool::Write_Result(std::vector<ASCS_Population> &populations, Config &cof, BooleanEnvironment &env, CompactionMechanism &CM)
{
	//save the population information
	string name  =PopulationPool::Generate_File_Name(cof, env);

	string P_name = ".\\Result\\P_" +name;

	ofstream outfile(P_name);

	string P_result = PopulationPool::Population_Result(populations);

	outfile << P_result;

	outfile.close();

	string T_result = PopulationPool::Trained_Result(populations, CM,cof);

	//save the trained information
	string T_name= ".\\Result\\T_" + name;

	ofstream savefile(T_name);

	savefile << T_result;

	savefile.close();

}

//convert the population result to string
string PopulationPool::Population_Result(std::vector<ASCS_Population> &populations)
{
	string result = "";
	int total_size = 0;
	for (int p = 0; p < populations.size(); ++p)
	{
		total_size += populations[p].num_Rules;
		for (int c = 0; c < populations[p].Clusters.size(); ++c)
		{
			for (int r = 0; r < populations[p].Clusters[c].Rules.size(); ++r)
			{
				for (int i = 0; i < populations[p].Clusters[c].Rules[r].condition.size(); ++i)
				{
					result += populations[p].Clusters[c].Rules[r].condition[i]+" ";
				}
				result += "-> " + to_string(populations[p].Action) + "  NP:" + to_string(populations[p].Clusters[c].Rules[r].N_p) + "  PP:"
					+ to_string(populations[p].Clusters[c].Rules[r].P_p)+"\n";
			}
		}
	
	}
	result += to_string(total_size)+"\n";
	return result;
}

//save the trained result 
string PopulationPool::Trained_Result(std::vector<ASCS_Population> &populations, CompactionMechanism &CM, Config &cof)
{
	string result = "";
	result += "Test_Before: ";
	for (int i = 0; i < CM.P_Rlist_Before.size(); ++i)
	{
		result += to_string(CM.P_Rlist_Before[i]) + " ";
	}
	result += "\n";
	result += "Test_After: ";
	for (int i = 0; i < CM.P_Rlist_After.size(); ++i)
	{
		result += to_string(CM.P_Rlist_After[i]) + " ";
	}
	result += "\n";

	//initial the vectors for the record results
	std::vector<int> T_Cover;
	std::vector<int> T_Sub;
	std::vector<int> T_Ab;
	std::vector<int> T_Evo;
	std::vector<int> C_Sub;
	std::vector<int> C_Ab;
	std::vector<int> C_Error;

	for (int i = 0; i < cof.epoches; ++i)
	{
		int T_C = 0;
		int T_S = 0;
		int T_A = 0;
		int T_E = 0;
		int C_S = 0;
		int C_A = 0;
		int C_E = 0;

		for (int p = 0; p < populations.size(); ++p)
		{
			for (int c = 0; c < populations[p].Clusters.size(); ++c)
			{
				T_C += populations[p].Clusters[c].T_Cov_num[i];
				T_S += populations[p].Clusters[c].T_Subsumed_num[i];
				T_A += populations[p].Clusters[c].T_Aubsumed_num[i];
				T_E += populations[p].Clusters[c].T_Evolved_num[i];
				C_S += populations[p].Clusters[c].C_Subsumed_num[i];
				C_A += populations[p].Clusters[c].C_Aubsumed_num[i];
				C_E += populations[p].Clusters[c].C_Error_num[i];
			}
		}
		T_Cover.push_back(T_C);
		T_Sub.push_back(T_S);
		T_Ab.push_back(T_A);
		T_Evo.push_back(T_E);
		C_Sub.push_back(C_S);
		C_Ab.push_back(C_A);
		C_Error.push_back(C_E);
	}
	result += PopulationPool::Convert_Vector(T_Cover, "Cover:");
	result += PopulationPool::Convert_Vector(T_Sub, "Train Subsumption:");
	result += PopulationPool::Convert_Vector(T_Ab, "Train Absumption");
	result += PopulationPool::Convert_Vector(T_Evo, "Train Evo:");
	result += PopulationPool::Convert_Vector(C_Sub, "Compaction Subsumption:");
	result += PopulationPool::Convert_Vector(C_Ab, "Compaction inconsistent:");
	result += PopulationPool::Convert_Vector(C_Error, "Compaction Error:");

	return result;
}

//get the converted vector
string PopulationPool::Convert_Vector(std::vector<int> &information, string begin)
{
	string result = "";
	result += begin +" ";
	for (int i = 0; i < information.size(); ++i)
	{
		result += to_string(information[i])+" ";
	}
	result += "\n";
	return result;
}
