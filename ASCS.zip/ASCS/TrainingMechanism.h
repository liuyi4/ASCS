#pragma once;
using namespace std;
#include <vector>;
#include "Rule_001.h";
#include "PopulationPool.h";
#include "Rule001_Oper.h";
#include "MatchList.h";
#include "BooleanEnvironment.h";
#include <time.h>;
#include "Config.h"





class TrainingMechanism
{
public:
	//Constructor of the Training Mechanism
	TrainingMechanism(Config &cof);

	//get the matchset
	MatchList GetMatchList(std::vector<string> &state, std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &I_Action);

	//covering an received instance
	MatchList Covering(std::vector<string> &state, std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &I_Action);

	//run the training mechanism one time
	int TrainingOnce(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, BooleanEnvironment &env);

	//implement the absumption
	void Absumption(std::vector<ASCS_Population> &Populations, std::vector<std::vector<int>> &Ab_List, std::vector<string> &state, Rule001_Oper &R_O);

	//asscert whether this rule have already adhere in the population
	bool RuleExist(ASCS_Population &Population, std::vector<string> &condition, int &GeneralLevel, Rule001_Oper &R_O);

	//check whether this rule can be subsumed by any other rule
	bool RuleSubsumed(ASCS_Population &Population, std::vector<string> &condition, int &GeneralLevel, Rule001_Oper &R_O);

	//remove the incorrect rules in the absumption list
	void AbsumptionRemover(std::vector<ASCS_Population> &Populations, std::vector<std::vector<int>> &Ab_List);

	//Implement the Informed mutation
	void InformedMutation(std::vector<ASCS_Population> &Populations, std::vector<std::vector<int>> &IF_List, Rule001_Oper &R_O);

	//Run the training mechanism
	void run(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, BooleanEnvironment &env);

private:
	Config cof;

	int length;


	int seed = (unsigned)time(NULL);

};

