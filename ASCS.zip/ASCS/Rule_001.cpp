#include "Rule_001.h";


Rule_001::Rule_001(std::vector<string> &condition, std::vector<int> attributelist)
{


    //The input action from envirtomental instance
	//Rule_001::A = action;

	//The state (condition)
	Rule_001::condition = condition;

	Rule_001::Attributelist = attributelist;

	//Initial positive experience as 0
	Rule_001::P_p = 0;


	//Initial negative experience as 0
	Rule_001::N_p = 0;



	//Initial the subsumption state as False
	Rule_001::Sub_state = false;



}