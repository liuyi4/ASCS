#pragma once

class Config
{
public:
	/* About the problem setting*/
	//the Id of the problem
	//in a boolean environment 0:MUX 1:Carry 2:MajorityOn 3:Evenparity
	int problem_Id = 1;

	//definition the length of the boolean problem
	//notice MUX only support 3,6,11,20,37,70,135,264,521,1034,2059
	int problem_length = 6;


	/*About the training setting*/
	//the number of epoches, training will be completed after all the epoches are completed
	int epoches = 10;

	//the number of training iterations in each epoch
	int T_number = 500;

	//the number of instances need to be reviewed in the compaction process
	int C_number = 100;


	

	/*Additional control*/
	//population maximal size
	int P_Size = 80;


	/*For test*/
	//the number of the rules for testing
	int Test_num = 100;

	bool Test_Control = true;
};