#include <iostream>;
#include "Rule_001.h";
#include "BooleanEnvironment.h";
#include "PopulationPool.h";
#include "Rule001_Oper.h";
#include "TrainingMechanism.h";
#include <string>;
#include "MatchList.h";
#include "CompactionMechanism.h"
#include "Config.h"
using namespace std;




int main()
{
	std::string s;
	s = "Hello world";
	std::cout << s;
	std::cout << "Begin ASCS" << std::endl;
	//Initial the cofigure document
	Config cof;
	BooleanEnvironment env(cof.problem_Id, cof.problem_length); //= new BooleanEnvironment(0, 0);
	std::cout << "Problem Type: " << env.ProblemName[cof.problem_Id] << "   " <<
		"Problem Length: " << cof.problem_length << std::endl;


	// initialize this population and its operators
	PopulationPool P_Pool;
	Rule001_Oper RO(cof.problem_length);	
	std::vector<ASCS_Population> Population_P = P_Pool.initial_Population_Pool(cof.problem_length, env.action_list);


	// initial the learning mechanism
	TrainingMechanism TM(cof);
	CompactionMechanism CM(cof);

	for (int i = 0; i < cof.epoches; i++)
	{
		//run the learning process
		TM.run(Population_P, RO, env);

		//run the compacting process
		CM.run(Population_P, env, RO);

		//Update the search space control for the covering and recording the training performance
		if (i != cof.epoches - 1)
		{
			P_Pool.UpdateSearchSpace(Population_P);
		}
	}

	//print the trained populations
	P_Pool.Print_Population(Population_P);

	P_Pool.Write_Result(Population_P,cof,env, CM);

	system("pause");
	
	return 0;
}

