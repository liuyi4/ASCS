#include "BooleanEnvironment.h";
using namespace std;
#include <iostream>;
#include <stdlib.h>;  
#include<stdlib.h>;
#include<time.h>;
#include <string>;
#include <cmath>;

BooleanEnvironment::BooleanEnvironment(int problemID, int Length)
{
	BooleanEnvironment::condition_length = Length;

	BooleanEnvironment::problemID = problemID;

	//initial the action list
	BooleanEnvironment::action_list.push_back(0);
	BooleanEnvironment::action_list.push_back(1);

	//if MUX set the postbits (address bits)
	if (BooleanEnvironment::problemID==0);
	{
		BooleanEnvironment::Set_MUX_Posbit();
	}

	//Test the algorithms
	//std::vector<int> state=BooleanEnvironment::Create_set_Condition();
	//std::vector<string> state_s = BooleanEnvironment::Convert_state_char(state);
	//BooleanEnvironment::execute_Multiplexer(state);
	//BooleanEnvironment::execute_Carry(state);
	//BooleanEnvironment::execute_Majority_On(state);
	//BooleanEnvironment::execute_even_parity(state);
	//BooleanEnvironment::execute_Problem(state);
}


//Set the post bits for the MUX problem
void BooleanEnvironment::Set_MUX_Posbit()
{
	int B_count = -1;
	auto star = std::rbegin(BooleanEnvironment::MUX_Length_array);
	auto end = std::rend(BooleanEnvironment::MUX_Length_array);
	while (end!=star)
	{
		end--;
		B_count++;
		//std::cout<< "The sum of elements in reverse order is " << *end << std::endl;

		if (*end == BooleanEnvironment::condition_length)
		{
			//std::cout << B_count << std::endl;
			//std::cout << *end <<"&&&&&&"<< BooleanEnvironment::MUX_posbit_array[B_count] << std::endl;
			BooleanEnvironment::MUX_posbit = BooleanEnvironment::MUX_posbit_array[B_count];
			//std::cout << BooleanEnvironment::MUX_posbit << std::endl;
			break;
		}
	}
}




//Random generate a instance's state Int format: for calculating the action
std::vector<int>  BooleanEnvironment::Create_set_Condition()
{
	std::vector<int> state;
	srand(seed);
	seed++;
	int value;
	for (int i = 0; i < BooleanEnvironment::condition_length; i++)
	{
		value = rand() % 2;
		//std::cout <<value << std::endl;
		state.push_back(value);
	}
	
	//Test: print state
	//for (int i = 0; i < BooleanEnvironment::condition_length; i++)
	//{
	//	std::cout << state[i] ;
	//}
	//std::cout << std::endl;
	return state;
}




// convert an instance from int format to string format for comparing the conditions
std::vector<string> BooleanEnvironment::Convert_state_char(std::vector<int> &state_I)
{
	std::vector<string> state;

	string value;
	//store the char
	for (int i = 0; i < BooleanEnvironment::condition_length; i++)
	{

		value= std::to_string(state_I[i]);
		//std::cout <<value;
		state.push_back(value);
	}

	// Test: print state
	/*for (int i = 0; i < BooleanEnvironment::condition_length; i++)
	{
			std::cout << state[i];
     }
	std::cout << std::endl;*/
	return state;
}


//execute the MUX
int BooleanEnvironment::execute_Multiplexer(std::vector<int> &state)
{
	int action;
	int address=0;

	for (int i = 0; i<BooleanEnvironment::MUX_posbit;i++)
	{
		//std::cout << i << std::endl;
		//value = pow(2,state[i]);
		if (state[i] == 1)
		{
			address += pow(2, BooleanEnvironment::MUX_posbit-i-1);
		}
	}
	//std::cout << address << std::endl;

	action = state[BooleanEnvironment::MUX_posbit+address];
	//std::cout << action << std::endl;
	return action;
}



//execute the carry
int BooleanEnvironment::execute_Carry(std::vector<int> &state)
{
	int action=0;
	int half_condition = BooleanEnvironment::condition_length / 2;
	//std::cout << half_condition << std::endl;
	for (int i=0; i <half_condition; i++)
	{
		action = (action+ state[half_condition-i-1]+state[BooleanEnvironment::condition_length-1-i])/2;
		//std::cout << half_condition - i - 1 << std::endl;
		//std::cout << BooleanEnvironment::condition_length - 1 - i << std::endl;
		//std::cout << action<< std::endl;
		//std::cout << "=========================" << std::endl;
	}
	//std::cout << action << std::endl;
	//std::cout << "***********************************" << std::endl;
	return action;
}


//execute the Majority-On problem
int BooleanEnvironment::execute_Majority_On(std::vector<int> &state)
{
	int action=0;
	//count the number of the 0 and 1 respectively
	int z_count = 0;
	int half_condition = BooleanEnvironment::condition_length / 2;

	for (int i=0; i<BooleanEnvironment::condition_length;i++)
	{
		if (state[i] == 0)
		{
			z_count++;
		}
	}

	if (z_count<=half_condition)
	{
		action = 1;
	}
	//std::cout << action << std::endl;
	return action;
}


//execute the even parity problem
int BooleanEnvironment::execute_even_parity(std::vector<int> &state)
{
	int action = 0;
	//count the number of the 0 and 1 respectively
	int z_count = 0;
	for (int i = 0; i<BooleanEnvironment::condition_length; i++)
	{
		if (state[i] == 0)
		{
			z_count++;
		}
	}

	if (z_count%2==0)
	{
		action = 1;
	}
	//std::cout << action << std::endl;
	return action;
}

int BooleanEnvironment::execute_Problem(std::vector<int> &state)
{
	int action = 0;
	switch (BooleanEnvironment::problemID)
	{
	case 0://MUX
		action= BooleanEnvironment::execute_Multiplexer(state);
		break;
	case 1://Carry
		action= BooleanEnvironment::execute_Carry(state);
		break;
	case 2://Majority-On
		action= BooleanEnvironment::execute_Majority_On(state);
		break;
	case 3://Even Parity
		action= BooleanEnvironment::execute_even_parity(state);
		break;
	default:
		break;
	}
	//std::cout << action << std::endl;
	return action;
}