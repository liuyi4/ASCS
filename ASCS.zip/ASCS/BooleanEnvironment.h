#pragma once;
using namespace std;
#include <vector>;
#include <array>;
#include<time.h>;

class BooleanEnvironment
{
	public:

		BooleanEnvironment(int ID, int Length);


		//number of actions
		int action_number = 2;

		//list of the actions
		std::vector<int> action_list;

		/*Execute functions*/
		//Create a state
		std::vector<int> Create_set_Condition();


		//convert the state to char vector
		std::vector<string> Convert_state_char(std::vector<int> &state);


		


		//execute the selected problem
		int execute_Problem(std::vector<int> &state);

		// the name of the Boolean problems
		std::array<string, 4> ProblemName{ "Multiplexer","Carry","Majority-On","Even_Parity" };
private:

	


	//exected problem ID
	//0: Multiplexer
	//1: Carry
	//2 Majority-On
	//3 Even parity
	int problemID;




	/* For the MUX (multiplexr) problem*/

	// the post bits for the Multiplexer problem
	std::array<int, 11> MUX_posbit_array{ 1,2,3,4,5,6,7,8,9,10,11 };


	// the lengh of the condition for the Multiplexer problem
	std::array<int, 11> MUX_Length_array{ 3,6,11,20,37,70,135,264,521,1034,2059 };

	//the value of the post bits
	int MUX_posbit;





	/* condition size and Action size*/

	


	//the length of the condition
	int condition_length;


	//set the address bits for the MUX
	void Set_MUX_Posbit();


	//execute the Multiplexer problem
	int execute_Multiplexer(std::vector<int> &state);


	//execute the Carry problem
	int execute_Carry(std::vector<int> &state);


	//execute the Majority-On problem
	int execute_Majority_On(std::vector<int> &state);



	//execute the even-parity
	int execute_even_parity(std::vector<int> &state);

	int seed = (unsigned)time(NULL);

};
