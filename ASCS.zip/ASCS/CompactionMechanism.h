#pragma once
using namespace std;
#include <vector>;
#include<string>;
#include <iostream>;
#include "Rule_001.h";
#include "PopulationPool.h";
#include "Rule001_Oper.h";
#include "MatchList.h";
#include "BooleanEnvironment.h";
#include "Config.h"

class CompactionMechanism
{
public:
	CompactionMechanism(Config &cof);

	//Run the compaction mechanism
	void run(std::vector<ASCS_Population> &populations, BooleanEnvironment &env, Rule001_Oper &R_O);



	//vector for storing the tested result
	vector<int> P_Rlist_Before{};

	vector<int> P_Rlist_After{};


	/*functions of the inconsistent remover*/
	std::vector<std::vector<int>> Prediction_update(std::vector<string> &state, std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &I_Action, vector<int> &P_List);


	//initial a prediction list
	vector<int> Prediction_List(int &numActions);


	//reset the value of the prediction list
	void EmptyPrediction_List(vector<int> &P_List);

	//Is prediction correct true:correct false:incorrect or unmatched
	bool Prediction_Result(vector<int> &P_List, int &realAction);


	//check whether the rule is inconsistant
	bool IsInconsistent(bool &PN_state, int &P_Action, int &R_Action);


	//remove the rules in the remove list
	void RuleRemover(std::vector<ASCS_Population> &Populations, std::vector<std::vector<int>> &R_List);

	//execute the inconsistent remover
	void inconsistent_remover(std::vector<ASCS_Population> &populations, BooleanEnvironment &env, Rule001_Oper &R_O);


	/*Functions of the erro remover*/
	//exeID 0: Error check by rules in the same generalization or lower
	//exeID 1: Error check by rules in a higher generalization level
	//Get the potential incorrect rules in the population
	std::vector<std::vector<int>> Error_List(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &exeID);

	//asscert whether this rule is correct
	bool IsCorrect(std::vector<ASCS_Population> &Populations, int &p, int c, int &r, Rule001_Oper &R_O);


	//asscert whether this rule is correct for remove the very specific rules
	bool IsCorrect_Specific(std::vector<ASCS_Population> &Populations, int &p, int c, int &r, Rule001_Oper &R_O);

	//execute the error remover
	void Error_remover(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &exeID);


	/*Functions for the Subsumption*/
	//get the subsumed list
	std::vector<std::vector<int>> Subsum_List(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O);

	//asscert whether this rule can be subsumed
	bool IsSubsumed(ASCS_Population &population, std::vector<string> &condition, Rule001_Oper &R_O, int &generalizationLevel);

	//execute the subsume
	void Subsume(std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O);

	/*functions for updatting rules' subsume state*/
	//update the subsumption state for the remained rules
	void UpdateSubState(std::vector<ASCS_Population> &Populations);


    /*functions for test the population*/
	//the result of the prediction 
	void PredictionAccuracy(std::vector<ASCS_Population> &populations, BooleanEnvironment &env, Rule001_Oper &R_O);

	//update the prediction list
	void UpdatepredictionList(std::vector<string> &state, std::vector<ASCS_Population> &Populations, Rule001_Oper &R_O, int &I_Action, vector<int> &P_List);

	/* functions for control the searchable of the clusters */
	void UpdateClustersVailable(std::vector<ASCS_Population> &populations);

private:
	Config cof;

	



};