#include "Rule001_Oper.h";
#include "Rule_001.h";
#include <iostream>;
#include <stdlib.h>;  
#include<stdlib.h>;
#include<time.h>;
#include <string>;
using namespace std;



//initial the attribute list
Rule001_Oper::Rule001_Oper(int problem_length)
{
	//initial the problem length and the attribute list
	Rule001_Oper::PL = problem_length;
	

	//Initilize the attribute list
	for (int i = 0; i < problem_length; ++i)
	{
		Rule001_Oper::AL.push_back(i);
		//std::cout << AL[i] << std::endl;	
	}

	//for (int i = 0; i < problem_length; ++i)
	//{
	//	std::cout << AL[i] << " ";
	//}
}


//create a new rule
Rule_001 Rule001_Oper::CreateRule(int general_level, std::vector<string> state)
{
	//randomly detect the attributes that will be generalized	
	int random_location;
	srand(Rule001_Oper::seed);
	Rule001_Oper::seed++;
	for (int i = 0; i < general_level; ++i)
	{
		random_location = rand() % Rule001_Oper::PL;
		swap(Rule001_Oper::AL[i], Rule001_Oper::AL[random_location]);
	}


	//initialize the condition for a rule
	std::vector<string> condition{};
	for (int i = 0; i < Rule001_Oper::PL; ++i)
	{
		if (std::find(Rule001_Oper::AL.begin(), Rule001_Oper::AL.begin()+ general_level, i) != Rule001_Oper::AL.begin() + general_level)
		{
			condition.push_back("#");
		}
		else
		{
			condition.push_back(state[i]);
		}
	}



	//check the condition and the attribute list
	/*for (int i = 0; i < general_level; ++i)
	{
		std::cout << General_List[i] << " ";
	}

	std::cout << std::endl;
	for (int i = 0; i < Rule001_Oper::PL; ++i)
	{
		std::cout << condition[i] << " ";
	}*/

	Rule_001 rule(condition, Rule001_Oper::AL);
	return rule;
}


//identify whether a rule matched an state
bool Rule001_Oper::IsConditionMatch(std::vector<string> &state, std::vector<string> &condition)
{
	bool result = true;
	for (int i = 0; i < state.size(); ++i)
	{
		if (condition[i] != "#" && condition[i]!=state[i])
		{
			return false;
		}
	}

	return result;
}




//asscert whether this rule belong to absumption set together with updatting the training parameters
bool Rule001_Oper::IsAbsumptionAndUpdate(Rule_001 &rule, int &realAction, int &populationAction, bool &PNstate)
{
	//false: informed mutation; true: absumption set
	bool result = false;

	//judge whether the environment action is equilivant to the population's action
	bool consistent =false;
	if (realAction == populationAction)
	{
		consistent = true;
	}
    
	//rule is inconsistent thus should be classified into absumption set otherwise the rule should be send into 
	//informed operator set
	if (!(PNstate ^ consistent))
	{
		result = true;
	}


    if (consistent == true)
	{
	    rule.P_p++;
	}
	else
	{
         rule.N_p++;
	}
	


	return result;
}



//standard absumption correct one mistake one time
Rule_001 Rule001_Oper::AbRule(std::vector<string> &state, Rule_001 rule, int &generalizationlevel)
{
	//initial the training parameters
	rule.N_p = 0;
	rule.P_p = 0;
	rule.Sub_state = false;

	//random seed
	srand(Rule001_Oper::seed);
	Rule001_Oper::seed++;
	//the correct location 
	int correct_location = rand() % (generalizationlevel);
	//std::cout << correct_location << std::endl;


	//correct the mistaken
	if (state[rule.Attributelist[ correct_location ] ] == "0")
	{
		rule.condition[rule.Attributelist[correct_location]] = "1";
	}
	else
	{
		rule.condition[rule.Attributelist[correct_location]] = "0";
	}

	//change the attribute list
	swap(rule.Attributelist[correct_location], rule.Attributelist[(generalizationlevel - 1)]);

	return rule;
}


//asscert whether two condistions are the same     true: same;  false: not
bool Rule001_Oper::SameCondition(std::vector<string> &old_condition, std::vector<string> &new_condition)
{
	for (int i = 0; i < old_condition.size(); ++i)
	{
		if (old_condition[i] != new_condition[i])
		{
			return false;
		}
	}
	return true;
}



//asscert whether old condition can subsume new condition      true:can; false:not
bool Rule001_Oper::SubsumeCondition(std::vector<string> &old_condition, std::vector<string> &new_condition)
{
	for (int i = 0; i < old_condition.size(); ++i)
	{
		if (old_condition[i]!="#" && old_condition[i] != new_condition[i])
		{
			return false;
		}
	}
	return true;
}


//generate a informed rule, where generalization level is exactly the generalization level of this rule
Rule_001  Rule001_Oper::InformRule(Rule_001 rule, int &generalizationlevel)
{
	//initial the training parameters
	rule.N_p = 0;
	rule.P_p = 0;
	rule.Sub_state = false;


	//random seed
	srand(Rule001_Oper::seed);
	Rule001_Oper::seed++;
	int specific_level = Rule001_Oper::PL - generalizationlevel;
	int general_location= (rand() % (specific_level))+ generalizationlevel;

	//make the selected attribute become general
	rule.condition[rule.Attributelist[general_location]] = "#";

	//change the attribute list
	swap(rule.Attributelist[general_location], rule.Attributelist[generalizationlevel]);

	return rule;
}

bool Rule001_Oper::OverlapCondition(std::vector<string> &condition1, std::vector<string> &condition2)
{
	for (int i = 0; i < condition1.size(); ++i)
	{

		if( (condition1[i] != "#")&&(condition2[i]!="#")&&(condition1[i]!=condition2[i]) )
		{
			return false;
		}
	}
	return true;
}