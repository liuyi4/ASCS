#pragma once;
using namespace std;
#include <vector>;
#include "Rule_001.h";



class ASCS_Cluster
{
public:

	ASCS_Cluster();

	//for identify whether rhis cluster can be used to create new rule i.e. cover and General search exclude the subsumption
	bool Active = true;


	//record the information for training mechanism

	//number of the subsumed rules
	std::vector<int> T_Subsumed_num{};

	//number of the absumed rules
	std::vector<int> T_Aubsumed_num{};

	//number of the new created rules
	std::vector<int> T_Evolved_num{};


	//number of the covered rules
	std::vector<int> T_Cov_num{};

	//record the information for compaction mechanism

	//number of the subsumed rules
	std::vector <int> C_Subsumed_num{};

	//number of the absumed rules
	std::vector<int> C_Aubsumed_num{};

	//number of the error removed rules
	std::vector<int> C_Error_num{};

	//the repositied rules
	std::vector<Rule_001> Rules{};
};
